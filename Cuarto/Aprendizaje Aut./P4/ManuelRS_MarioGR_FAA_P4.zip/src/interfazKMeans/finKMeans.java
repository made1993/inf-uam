package interfazKMeans;

import java.util.ArrayList;

public interface finKMeans {
	
	public boolean fin(ArrayList<Double[]> centroides, ArrayList<Integer> clusters);

}
