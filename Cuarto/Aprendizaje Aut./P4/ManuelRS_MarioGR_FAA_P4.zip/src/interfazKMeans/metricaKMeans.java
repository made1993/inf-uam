package interfazKMeans;

public interface metricaKMeans {
	public double metrica(Double [] x1, Double []  x2);

}
