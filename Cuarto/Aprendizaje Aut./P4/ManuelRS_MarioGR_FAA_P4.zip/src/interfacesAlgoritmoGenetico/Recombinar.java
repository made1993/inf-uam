package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.*;

public interface Recombinar {
	
	public Poblacion recombinar(Poblacion p);

}
