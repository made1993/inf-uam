package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.Poblacion;

public interface SelectPadres {
	
	public Poblacion selectPadres(Poblacion p);

}
