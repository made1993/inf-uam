package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.*;
import datos.*;

public interface Fitness {
	public void fit(Poblacion p, Datos datos);
	public void generarBitSets(Datos datos);

}
