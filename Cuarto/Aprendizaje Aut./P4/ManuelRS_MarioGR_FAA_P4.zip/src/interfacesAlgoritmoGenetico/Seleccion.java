package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.Poblacion;

public interface Seleccion {
	public Poblacion seleccionar(Poblacion p1, Poblacion p2);
}
