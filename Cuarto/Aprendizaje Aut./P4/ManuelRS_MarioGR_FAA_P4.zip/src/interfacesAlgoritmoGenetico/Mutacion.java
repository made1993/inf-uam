package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.*;

public interface Mutacion {

	public void mutar(Poblacion p);
}
