package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGenetico.Poblacion;

public interface IniPoblacion {
	public Poblacion crearPoblacion();
}
