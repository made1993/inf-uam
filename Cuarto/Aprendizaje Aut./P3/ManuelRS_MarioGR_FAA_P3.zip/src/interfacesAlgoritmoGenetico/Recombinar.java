package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGentecio.*;

public interface Recombinar {
	
	public Poblacion recombinar(Poblacion p);

}
