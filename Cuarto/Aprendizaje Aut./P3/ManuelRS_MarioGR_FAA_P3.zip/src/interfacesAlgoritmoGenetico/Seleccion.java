package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGentecio.Poblacion;

public interface Seleccion {
	public Poblacion seleccionar(Poblacion p1, Poblacion p2);
}
