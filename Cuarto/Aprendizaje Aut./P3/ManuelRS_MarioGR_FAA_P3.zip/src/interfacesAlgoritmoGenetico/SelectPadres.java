package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGentecio.Poblacion;

public interface SelectPadres {
	
	public Poblacion selectPadres(Poblacion p);

}
