package interfacesAlgoritmoGenetico;

public interface EndAlgGen {
	public boolean end(double fit);
}
