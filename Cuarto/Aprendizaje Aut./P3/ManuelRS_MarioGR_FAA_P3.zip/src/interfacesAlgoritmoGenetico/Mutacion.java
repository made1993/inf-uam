package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGentecio.*;

public interface Mutacion {

	public void mutar(Poblacion p);
}
