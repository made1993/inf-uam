package interfacesAlgoritmoGenetico;

import clasesAlgoritmoGentecio.Poblacion;

public interface IniPoblacion {
	public Poblacion crearPoblacion();
}
