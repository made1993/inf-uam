package base;

import base.Entity;
import interfaces.ITable;

import java.util.*;

import exceptions.PropertyNoValida;
import typeDescriptors.TypeDescriptor;

/**
 * Clase para implementar la tabla
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Table implements ITable {

	private Map<Long, Map<String, Object>> map = new HashMap<Long, Map<String, Object>>();
	private TypeDescriptor td;
	private long serial;
	private Map<String, Index> indexmap = new HashMap<String, Index>();
	/**
	 * Constructor de la clase
	 *
	 */
	public Table(TypeDescriptor t) {
		this.td = t;
		this.serial = 0L;
	}
	
	/**
     * Metodo para obtener el tipo
     * @return el tipo
     */
	@Override
	public TypeDescriptor getType() {
		return this.td;
	}

	/**
     * Metodo para obtener una entity
     * @param id Long de la entity
     * @return la entity
     */
	@Override
	public Entity getEntity(Long id) {
		List<String> properties = new ArrayList<String>();

		try {
			properties = this.getType().getProperties();
			Entity e = this.getType().newEntity();

			for (String s : properties) {
				try {
					e.setProperty(s, map.get(id).get(s));
				} catch (PropertyNoValida e1) {}
			}
			return e;
		} catch (NullPointerException ex) {
			System.out.println("No existe esa entrada en la tabla");
			return null;
		}
	}
	
	/**
     * Metodo para actualizar una entity
     * @param e entity a actualizar
     * @return id de la entity
     */
	@Override
	public long updateEntity(Entity e) {
		if (e.getId() == null) {// es una entidad nueva, a�adir sus valores al
								// index
			e.setId(serial);
			this.serial++;
		} else {// entidad antigua, borrar, borrar del indice y crear de nuevo
			this.delete(e);
		}
		Map<String, Object> m = new HashMap<String, Object>();
		//e = e.getClass().cast(e);
		List<String> properties = e.getProperties();
		
		Index index = new Index();
		
		if((e.getType()=="Disco")||(e.getType()=="Libro")||(e.getType()=="Pelicula")){
			index.add(e.getProperty("titulo"), e.getId());
			for (String s : properties) {
				m.put(s, e.getProperty(s));
				try {
					this.indexmap.put("titulo", index);
				} catch (NullPointerException exception) {
				}
			}
		}else{
			index.add(e.getProperty("nombre"), e.getId());
			for (String s : properties) {
				m.put(s, e.getProperty(s));
				try {
					this.indexmap.put("nombre", index);
				} catch (NullPointerException exception) {
				}
			}
		}

		this.map.put(e.getId(), m);
		return e.getId();
	}

	/**
     * Metodo para borrar entidades
     * @param e entidad a borrar
     */
	@Override
	public void delete(Entity e) {
		this.map.remove(e.getId());
		List<String> properties = e.getProperties();
		for (String s : properties) {
			try{
			this.indexmap.get(s).deleteValue(e.getId());
			}catch(NullPointerException exception){}
		}
	}

	
	/**
     * Metodo para buscar una entity
     * @param property propiedad para buscar
     * @param value valor a buscar
     * @return coleccion de id de la entity
     */
	@Override
	public Collection<Long> search(String property, Object value) {
		/*
		 * Iterator<Long> keys = this.map.keySet().iterator(); Collection<Long>
		 * resultado = new HashSet<Long>();
		 * 
		 * while(keys.hasNext()){ if(
		 * this.map.get(keys.next()).get(property).equals(value) ){
		 * resultado.add(keys.next().longValue()); } } return
		 * Collections.unmodifiableSet((Set<Long>) resultado);
		 */
		return indexmap.get(property).search(value);
	}

	/**
     * Metodo para buscar una entity
     * @param property propiedad para buscar
     * @param value valor a buscar
     * @return coleccion de id de la entity
     */
	@Override
	public Collection<Long> search(String property, Object from, Object to) {
		return indexmap.get(property).search(from, to);
	}

}
