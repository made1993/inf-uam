package base;

import java.util.*;

import interfaces.IIndex;

/**
 * Clase para implementar el indice
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Index implements IIndex {

	private TreeMap<Object, Set<Long>> indice = new TreeMap<Object, Set<Long>>(
			new Comparator<Object>() {
				@Override
				public int compare(Object o1, Object o2) {
					if (o1 == null && o2 == null) {
						return 0;
					} else if (o1 == null) {
						return -1;
					} else if (o2 == null) {
						return 1;
					}
					return o1.toString().compareTo(o2.toString());
				}
			});

	/**
     * Metodo para a�adir un valor al indice
     * @param key clave donde a�adir
     * @param value valor a a�adir
     */
	@Override
	public void add(Object key, Long value) {
		try {
			indice.get(key).add(value);
		} catch (Exception e) {
			Set<Long> set = new HashSet<Long>();
			set.add(value);
			indice.put(key, set);
		}
	}

	/**
     * Metodo para borrar un valor al indice
     * @param key clave donde borrar
     * @param value valor a borrar
     */
	@Override
	public void delete(Object key, Long value) {

		Set<Long> set = indice.get(key);
		set.remove(value);
		if (set.size() == 0) {
			indice.remove(key);
		}
	}
	/**
     * Metodo para buscar en el indice
     * @param key clave a buscar
     * @return coleccion de id del objeto
     */
	@Override
	public Collection<Long> search(Object key) {
		return Collections.unmodifiableSet(indice.get(key));
	}
	/**
     * Metodo para buscar en el indice desde hasta
     * @param from clave a buscar desde
     * @param to clave a buscar hasta
     * @return coleccion de id del objeto
     */
	@Override
	public Collection<Long> search(Object from, Object to) {
		Collection<Set<Long>> set;
		Collection<Long> kiwi = new HashSet<Long>();
		Iterator<Set<Long>> iterator;
		try{
		if(from == null && to == null){
			set = indice.subMap(indice.firstKey(), true, indice.lastKey(), true).values();
			iterator = set.iterator();
			while(iterator.hasNext()){
				kiwi.addAll(iterator.next());
			}
		}else if(from == null){
			set = indice.subMap(indice.firstKey(), true, to, true).values();
			iterator = set.iterator();
			while(iterator.hasNext()){
				kiwi.addAll(iterator.next());
			}
		}else if(to == null){
			set = indice.subMap(from, true, indice.lastKey(), true).values();
			iterator = set.iterator();
			while(iterator.hasNext()){
				kiwi.addAll(iterator.next());
			}
		}else{
			set = indice.subMap(from, true, to, true).values();
			iterator = set.iterator();
			while(iterator.hasNext()){
				kiwi.addAll(iterator.next());
			}
		}
		}catch(IllegalArgumentException e){
			System.out.println("Error en los argumentos de search");
		}
		return Collections.unmodifiableSet((Set<Long>) kiwi);
	}
	
	/**
     * Metodo para borrar un valor al indice
     * @param value valor a borrar
     */
	public void deleteValue(Long value){
		Iterator<Object> keys = indice.keySet().iterator();
		while(keys.hasNext()){
			this.delete(keys.next(), value);
		}
	}
	
}
