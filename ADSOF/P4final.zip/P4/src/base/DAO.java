package base;

import interfaces.IDAO;

import java.util.*;

import typeDescriptors.TypeDescriptor;

/**
 * Clase para implementar el manejo de datos
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class DAO implements IDAO {
	
	private List<Table> listaTablas = new ArrayList<Table>();
	
	/**
     * Metodo para registrar tipos
     * @param t tipo a registrar
     */
	@Override
	public void registerType(TypeDescriptor t) {
		this.listaTablas.add(new Table(t));
	}

	/**
     * Metodo para obtener una entity
     * @param type tipo de entity
     * @param id Long de la entity
     * @return la entity
     */
	@Override
	public Entity getEntity(String type, Long id) {
		for(Table t: listaTablas){
			if(t.getType().getName().equals(type)){
				return t.getEntity(id);
			}
		}
		return null;
	}

	/**
     * Metodo para actualizar una entity
     * @param e entity a actualizar
     * @return id de la entity
     */
	@Override
	public long updateEntity(Entity e) {
		for(Table t: listaTablas){
			if(t.getType().getName().equals(e.getType())){
				return t.updateEntity(e);
			}
		}
		return -1L;
	}

	
	/**
     * Metodo para borrar entidades
     * @param e entidad a borrar
     */
	@Override
	public void delete(Entity e) {
		for(Table t: listaTablas){
			if(t.getType().getName().equals(e.getType())){
				t.delete(e);
			}
		}
	}

	/**
     * Metodo para buscar una entity
     * @param type tipo de entity
     * @param property propiedad para buscar
     * @param value valor a buscar
     * @return coleccion de id de la entity
     */
	@Override
	public Collection<Long> search(String type, String property, Object value) {
		Collection<Long> set = new HashSet<Long>();
		try{
		for(Table t: listaTablas){
			if(t.getType().getName().equals(type)){
				return t.search(property, value);
			}
		}
		return new HashSet<Long>();
		}catch(Exception exception){
			return set;
		}
	}
	
	/**
     * Metodo para buscar una entity desde hasta
     * @param type tipo de entity
     * @param property propiedad para buscar
     * @param from valor a buscar desde
     * @param from valor a buscar hasta
     * @return coleccion de id de la entity
     */
	@Override
	public Collection<Long> search(String type, String property, Object from, Object to) {
		Collection<Long> set = new HashSet<Long>();
		try{
		for(Table t: listaTablas){
			if(t.getType().getName().equals(type)){
				return t.search(property, from, to);
			}
		}
		return new HashSet<Long>();
		}catch(Exception exception){
			return set;
		}
	}


}
