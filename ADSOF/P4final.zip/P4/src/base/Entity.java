package base;

import java.util.List;

import exceptions.PropertyNoValida;

/**
 * Clase para implementar las entidades
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public abstract class Entity implements interfaces.IEntity {
	private Long id = null;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	/**
     * Metodo para obtener el tipo
     * @return el tipo
     */
	@Override
	public String getType() {
		return null;
	}
	/**
     * Metodo para obtener una propiedad
     * @param property tipo de propiedad
     * @return la propiedad
     */
	@Override
	public Object getProperty(String property) {
		return null;
	}
	/**
     * Metodo para obtener las propiedades
     * @return lista de propiedades
     */
	public List<String> getProperties() {
		return null;
	}
	/**
     * Metodo para poner una propiedad
     * @param property tipo de propiedad
     * @param value valor de la propiedad
     */
	@Override
	public void setProperty(String property, Object value) throws PropertyNoValida {
	}
}
