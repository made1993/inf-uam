package typeDescriptors;

import java.util.*;

import base.Entity;
import tienda.Director;

/**
 * Clase para implementar las propiedades y los tipos de datos de los directores
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class DirectorTypeDescriptor extends TypeDescriptor {
	
	private static DirectorTypeDescriptor INSTANCE;

	/**
     * Constructor de la clase
     */	
	private DirectorTypeDescriptor(){}
	
	/**
     * Metodo para crear una unica instancia
     * @return descriptor del director
     */
	public static DirectorTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new DirectorTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Director";
	}

	/**
     * Metodo para obtener las propiedades de un director
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
		}
		return null;
	}
	
	/**
     * Metodo para crear un director
     * @return director creado
     */
	@Override
	public Entity newEntity() {
		return new Director();
	}
}