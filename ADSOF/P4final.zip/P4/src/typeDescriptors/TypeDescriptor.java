package typeDescriptors;

import base.Entity;
import interfaces.ITypeDescriptor;

/**
 * Clase para implementar las propiedades y los tipos de datos de los objetos
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public abstract class TypeDescriptor implements ITypeDescriptor {

	/**
     * Metodo para crear una entidad
     * @return entidad creada
     */
	@Override
	public Entity newEntity() {
		return null;
	}

}
