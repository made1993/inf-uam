/**
 * 
 */
package typeDescriptors;

import java.util.ArrayList;
import java.util.List;

import base.Entity;
import tienda.Libro;

/**
 * Clase para implementar las propiedades y los tipos de datos de los libros
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class LibroTypeDescriptor extends TypeDescriptor{
	
	private static LibroTypeDescriptor INSTANCE;
	
	/**
     * Constructor de la clase
     */
	private LibroTypeDescriptor(){}
		
	/**
     * Metodo para crear una unica instancia
     * @return descriptor del libro
     */
	public static LibroTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new LibroTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Libro";
	}

	/**
     * Metodo para obtener las propiedades de un libro
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("autor");
		lista.add("editorial");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
			case "titulo":
				return Type.String;
			case "autor":
				return Type.Long;
			case "editorial":
				return Type.String;
		}
		return null;
	}

	/**
     * Metodo para crear un libro
     * @return libro creado
     */
	@Override
	public Entity newEntity() {
		return new Libro();
	}
	
	
	
	
}
