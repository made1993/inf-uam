package typeDescriptors;

import java.util.*;

import base.Entity;
import tienda.Autor;

/**
 * Clase para implementar las propiedades y los tipos de datos de los autores
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class AutorTypeDescriptor extends TypeDescriptor {
	
	private static AutorTypeDescriptor INSTANCE;

	/**
     * Constructor de la clase
     */	
	private AutorTypeDescriptor(){}

	/**
     * Metodo para crear una unica instancia
     * @return descriptor del autor
     */
	public static AutorTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new AutorTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Autor";
	}

	/**
     * Metodo para obtener las propiedades de un autor
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
		}
		return null;
	}

	/**
     * Metodo para crear un autor
     * @return autor creado
     */
	@Override
	public Entity newEntity() {
		return new Autor();
	}
}
