/**
 * 
 */
package typeDescriptors;

import java.util.ArrayList;
import java.util.List;

import base.Entity;
import tienda.Pelicula;

/**
 * Clase para implementar las propiedades y los tipos de datos de las peliculas
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class PeliculaTypeDescriptor extends TypeDescriptor{
	
	private static PeliculaTypeDescriptor INSTANCE;

	/**
     * Constructor de la clase
     */
	private PeliculaTypeDescriptor(){}

	/**
     * Metodo para crear una unica instancia
     * @return descriptor de la pelicula
     */
	public static PeliculaTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new PeliculaTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Pelicula";
	}

	/**
     * Metodo para obtener las propiedades de una pelicula
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("director");
		lista.add("genero");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
			case "titulo":
				return Type.String;
			case "director":
				return Type.Long;
			case "genero":
				return Type.String;
		}
		return null;
	}
	
	/**
     * Metodo para crear una pelicula
     * @return pelicula creada
     */
	@Override
	public Entity newEntity() {
		return new Pelicula();
	}
	
	
	
	
}
