package typeDescriptors;

import java.util.*;

import base.Entity;
import tienda.Interprete;

/**
 * Clase para implementar las propiedades y los tipos de datos de los interpretes
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class InterpreteTypeDescriptor extends TypeDescriptor {
	
	private static InterpreteTypeDescriptor INSTANCE;

	/**
     * Constructor de la clase
     */	
	private InterpreteTypeDescriptor(){}
	
	/**
     * Metodo para crear una unica instancia
     * @return descriptor del interprete
     */
	public static InterpreteTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new InterpreteTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Interprete";
	}

	/**
     * Metodo para obtener las propiedades de un interprete
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
		}
		return null;
	}
	
	/**
     * Metodo para crear un interprete
     * @return interprete creado
     */
	@Override
	public Entity newEntity() {
		return new Interprete();
	}
}