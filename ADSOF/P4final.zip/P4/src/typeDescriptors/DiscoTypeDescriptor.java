/**
 * 
 */
package typeDescriptors;

import java.util.ArrayList;
import java.util.List;

import base.Entity;
import tienda.Disco;

/**
 * Clase para implementar las propiedades y los tipos de datos de los discos
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class DiscoTypeDescriptor extends TypeDescriptor{
	
	private static DiscoTypeDescriptor INSTANCE;

	/**
     * Constructor de la clase
     */	
	private DiscoTypeDescriptor(){}
	
	/**
     * Metodo para crear una unica instancia
     * @return descriptor del disco
     */
	public static DiscoTypeDescriptor getInstance() {
		if (INSTANCE==null){
			INSTANCE = new DiscoTypeDescriptor();
		}
		return INSTANCE;
	}
	
	@Override
	public String getName() {
		return "Disco";
	}

	/**
     * Metodo para obtener las propiedades de un disco
     * @return lista de propiedades
     */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("interprete");
		lista.add("anno");
		return lista;
	}

	/**
     * Metodo para obtener el tipo de una propiedad
     * @return tipo
     */
	@Override
	public Type getType(String property) {
		switch(property){
			case "id":
				return Type.Long;
			case "titulo":
				return Type.String;
			case "interprete":
				return Type.Long;
			case "anno":
				return Type.Long;
		}
		return null;
	}

	/**
     * Metodo para crear un disco
     * @return disco creado
     */
	@Override
	public Entity newEntity() {
		return new Disco();
	}
	
	
	
	
}
