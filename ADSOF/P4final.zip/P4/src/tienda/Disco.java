/**
 * 
 */
package tienda;

import java.util.ArrayList;
import java.util.List;

import exceptions.PropertyNoValida;
import typeDescriptors.DiscoTypeDescriptor;

/**
 * Clase para implementar los discos
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Disco extends Articulo{
	
	private Long interprete;
	private Long anno;
	private static final DiscoTypeDescriptor descriptor = DiscoTypeDescriptor.getInstance();
	
	public Disco(){}

	public Long getInterprete() {
		return interprete;
	}

	public void setInterprete(Long value) {
		this.interprete = value;
	}

	public Long getAnno() {
		return anno;
	}

	public void setAnno(Long anno) {
		this.anno = anno;
	}

	public static DiscoTypeDescriptor getDescriptor(){
		return descriptor;
	}

	@Override
	public String getType() {
		return "Disco";
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @return Object El valor del campo pasado como parametro
	  *
	  */
	@Override
	public Object getProperty(String property) {
		switch(property){
			case "id":
				return this.getId();
			case "titulo":
				return this.getTitulo();
			case "interprete":
				return this.getInterprete();
			case "anno":
				return this.getAnno();
		}
		return null;
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @param Object El valor del campo que se quiere cambiar
	  *
	  */
	@Override
	public void setProperty(String property, Object value) throws PropertyNoValida {
		switch(property){
			case "id":
				this.setId((Long) value);
				break;
			case "titulo":
				this.setTitulo((String) value);
				break;
			case "interprete":
				this.setInterprete((Long) value);
				break;
			case "anno":
				this.setAnno((Long) value);
				break;
			default:
				throw new PropertyNoValida();
		}
		
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @return lista List<String> Lista de todos los atributos del objeto
	  *
	  */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("interprete");
		lista.add("anno");
		return lista;
	}
}
