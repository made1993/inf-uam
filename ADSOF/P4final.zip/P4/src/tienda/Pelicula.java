package tienda;

import java.util.ArrayList;
import java.util.List;

import exceptions.PropertyNoValida;
import typeDescriptors.PeliculaTypeDescriptor;
/**
 * Clase para implementar las peliculas
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Pelicula extends Articulo{
	private String genero;
	private Long director;
	private static final PeliculaTypeDescriptor descriptor = PeliculaTypeDescriptor.getInstance();
	
	public Pelicula(){}
	
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public Long getDirector() {
		return director;
	}
	public void setDirector(Long director) {
		this.director = director;
	}
	
	public static PeliculaTypeDescriptor getDescriptor(){
		return descriptor;
	}
	
	@Override
	public String getType() {
		return "Pelicula";
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @return Object El valor del campo pasado como parametro
	  *
	  */
	@Override
	public Object getProperty(String property) {
		switch(property){
			case "id":
				return this.getId();
			case "titulo":
				return this.getTitulo();
			case "director":
				return this.getDirector();
			case "genero":
				return this.getGenero();
		}
		return null;
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @param Object El valor del campo que se quiere cambiar
	  *
	  */
	@Override
	public void setProperty(String property, Object value) throws PropertyNoValida{
		switch(property){
			case "id":
				this.setId((Long) value);
				break;
			case "titulo":
				this.setTitulo((String) value);
				break;
			case "director":
				this.setDirector((Long) value);
				break;
			case "genero":
				this.setGenero((String) value);
				break;
			default:
				throw new PropertyNoValida();
		}
		
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @return lista List<String> Lista de todos los atributos del objeto
	  *
	  */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("director");
		lista.add("genero");
		return lista;
	}
}
