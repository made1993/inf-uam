/**
 * 
 */
package tienda;

import java.util.ArrayList;
import java.util.List;

import exceptions.PropertyNoValida;
import typeDescriptors.LibroTypeDescriptor;

/**
 * Clase para implementar los libros
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Libro extends Articulo{
	
	private Long autor;
	private String editorial;
	private static final LibroTypeDescriptor descriptor = LibroTypeDescriptor.getInstance();
	
	public Libro(){}

	public Long getAutor() {
		return autor;
	}

	public void setAutor(Long autor) {
		this.autor = autor;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	
	public static LibroTypeDescriptor getDescriptor(){
		return descriptor;
	}

	@Override
	public String getType() {
		return "Libro";
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @return Object El valor del campo pasado como parametro
	  *
	  */
	@Override
	public Object getProperty(String property) {
		switch(property){
			case "id":
				return this.getId();
			case "titulo":
				return this.getTitulo();
			case "autor":
				return this.getAutor();
			case "editorial":
				return this.getEditorial();
		}
		return null;
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @param Object El valor del campo que se quiere cambiar
	  *
	  */
	@Override
	public void setProperty(String property, Object value) throws PropertyNoValida{
		switch(property){
			case "id":
				this.setId((Long) value);
				break;
			case "titulo":
				this.setTitulo((String) value);
				break;
			case "autor":
				this.setAutor((Long) value);
				break;
			case "editorial":
				this.setEditorial((String) value);
				break;
			default:
				throw new PropertyNoValida();
		}		
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @return lista List<String> Lista de todos los atributos del objeto
	  *
	  */
	@Override
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("titulo");
		lista.add("autor");
		lista.add("editorial");
		return lista;
	}
}
