package tienda;

import typeDescriptors.InterpreteTypeDescriptor;
/**
 * Clase para definir los interpretes
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Interprete extends Persona{
	private static final InterpreteTypeDescriptor descriptor = InterpreteTypeDescriptor.getInstance();
	
	@Override
	public String getType() {
		return "Interprete";
	}
	
	public static InterpreteTypeDescriptor getDescriptor(){
		return descriptor;
	}
	
}
