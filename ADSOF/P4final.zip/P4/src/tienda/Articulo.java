/**
 * 
 */
package tienda;

import base.Entity;


/**
 * Clase para implementar los articulos
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public abstract class Articulo extends Entity{
	
	private String titulo;
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
}
