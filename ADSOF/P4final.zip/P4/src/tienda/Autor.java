/**
 * 
 */
package tienda;
import typeDescriptors.AutorTypeDescriptor;


/**
 * Clase para definir los autores
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Autor extends Persona{
	
	private static final AutorTypeDescriptor descriptor = AutorTypeDescriptor.getInstance();
	
	@Override
	public String getType() {
		return "Autor";
	}
	public static AutorTypeDescriptor getDescriptor(){
		return descriptor;
	}
	
}
