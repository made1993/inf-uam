package tienda;

import java.util.ArrayList;
import java.util.List;

import exceptions.PropertyNoValida;
/**
 * Clase para definir las personas
 *  
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public abstract class Persona extends base.Entity{

	private String nombre;
	private String apellidos;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @return Object El valor del campo pasado como parametro
	  *
	  */
	@Override
	public Object getProperty(String property) {
		switch(property){
			case "id":
				return this.getId();
			case "nombre":
				return this.getNombre();
			case "apellidos":
				return this.getApellidos();
		}
		return null;
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @param property String propiedad a obtener
	  * @param Object El valor del campo que se quiere cambiar
	  *
	  */
	@Override
	public void setProperty(String property, Object value) throws PropertyNoValida{
		switch(property){
			case "id":
				this.setId((Long) value);
				break;
			case "nombre":
				this.setNombre((String) value);
				break;
			case "apellidos":
				this.setApellidos((String) value);
				break;
			default:
				throw new PropertyNoValida();
		}
		
	}
	/**
	  * coge el valor de la propiedad pasado como string
	  *
	  * @return lista List<String> Lista de todos los atributos del objeto
	  *
	  */
	public List<String> getProperties() {
		List<String> lista = new ArrayList<String>();
		lista.add("id");
		lista.add("apellidos");
		lista.add("nombre");
		return lista;
	}
}
