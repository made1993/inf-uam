package tienda;
import typeDescriptors.DirectorTypeDescriptor;
/**
 * Clase para definir los directores
 * 
 * @author Roberto Garcia Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class Director extends Persona {
	private static final DirectorTypeDescriptor descriptor = DirectorTypeDescriptor.getInstance();
	
	@Override
	public String getType() {
		return "Director";
	}
	
	public static DirectorTypeDescriptor getDescriptor(){
		return descriptor;
	}
	
}
