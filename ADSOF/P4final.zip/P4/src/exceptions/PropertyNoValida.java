package exceptions;
/**
 * Excepci�n para propiedad no valida
 * 
 * @author Roberto Garc�a Teodoro
 * @author Jorge Guillen Alonso 
 *
 */
public class PropertyNoValida extends Exception{
     
    private static final long serialVersionUID = 1L;
    /**
	  * funcion que se ejecuta cuando salta una excepcion PropertyNoValida. simplemente imprime "Propiedad no valida"
	  *
	  */
    public PropertyNoValida(){
        System.out.println("Propiedad no valida");
    }
     
}
