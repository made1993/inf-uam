package pruebas;

import java.util.Collection;

import exceptions.PropertyNoValida;
import base.*;
import tienda.*;
import typeDescriptors.*;

public class PruebaDAO {
	public static void main(String[] args) {
		
		DAO dao = new DAO();
		Collection<Long> set;
		
		try {
		LibroTypeDescriptor typeLibro = LibroTypeDescriptor.getInstance();
		AutorTypeDescriptor typeAutor = AutorTypeDescriptor.getInstance();
		
		DiscoTypeDescriptor typeDisco = DiscoTypeDescriptor.getInstance();
		InterpreteTypeDescriptor typeInterprete = InterpreteTypeDescriptor.getInstance();
		
		PeliculaTypeDescriptor typePelicula = PeliculaTypeDescriptor.getInstance();
		DirectorTypeDescriptor typeDirector = DirectorTypeDescriptor.getInstance();
		
		/*Libro*/
		
		Libro l1 = (Libro) typeLibro.newEntity();
		Autor a1 = (Autor) typeAutor.newEntity();
		
		dao.registerType(typeAutor);
		dao.updateEntity(a1);
		
		
	    l1.setProperty("autor", a1.getId());
		
		dao.registerType(typeLibro);
		dao.updateEntity(l1);
		System.out.println("Id del autor del Libro es " + dao.getEntity("Libro", l1.getId()).getProperty("autor"));
		
        /*Pelicula*/
		
		Pelicula p1 = (Pelicula) typePelicula.newEntity();
		Director dr1 = (Director) typeDirector.newEntity();
		Director dr2 = (Director) typeDirector.newEntity();
		
		dao.registerType(typeDirector);
		dao.updateEntity(dr1);
		dao.updateEntity(dr2);
		
		p1.setProperty("director", dr2.getId());
		dao.registerType(typePelicula);
		dao.updateEntity(p1);
		System.out.println("Id del director de la pelicula es " + dao.getEntity("Pelicula", p1.getId()).getProperty("director"));
		
		/*Disco*/
		
		Disco d1 = (Disco) typeDisco.newEntity();
		Interprete i1 = (Interprete) typeInterprete.newEntity();
		Interprete i2 = (Interprete) typeInterprete.newEntity();
		
		d1.setProperty("titulo", "Guay");
		d1.setProperty("anno", 1994L);
		
		i1.setProperty("nombre", "Juan");
		i1.setProperty("apellidos", "Alonso");
		
		dao.registerType(typeInterprete);
		dao.updateEntity(i1);
		dao.updateEntity(i2);
		dao.updateEntity(i1);

		d1.setProperty("interprete", i1.getId());
		dao.registerType(typeDisco);
		dao.updateEntity(d1);
		System.out.println("Id del interprete del disco es " +dao.getEntity("Disco", d1.getId()).getProperty("interprete"));
		System.out.println("Id del titulo del disco es " +dao.getEntity("Disco", d1.getId()).getProperty("titulo"));
		
		/*Busqueda de un valor inexistente*/
		set = dao.search("Interprete", "nombre", "Pedro");
		if (set.isEmpty()) {
			System.out.println("Busqueda de Pedro sin exito");
		}

		System.out.println("Busqueda de Juan exitosa: " +dao.search("Interprete", "nombre", "Juan").toString());
		System.out.println("Busqueda de guay exitosa: " +dao.search("Disco", "titulo", "Guay").toString());
		
		/*Prueba de propiedad no valida*/
		d1.setProperty("nombre", "Hola");
		
		} catch (PropertyNoValida e) {}
		
	}
}
