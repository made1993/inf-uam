package pruebas;

import exceptions.PropertyNoValida;
import interfaces.ITypeDescriptor;
import tienda.Interprete;
import tienda.Disco;

public class PruebaDisco {
	public static void main(String[] args) {
		Disco d1= new Disco();
		d1.setTitulo("El Callado");
		String titulo=(String) d1.getProperty("titulo"); //devuelve "El Callado"
		System.out.println(titulo);
		ITypeDescriptor t1= Disco.getDescriptor(); //Ejemplo de m�todo para obtener el descriptor
		//Nota: Se deja a criterio del alumno la mejor forma de crear y obtener los descriptores
		System.out.println(t1.getName()); //devuelve "Libro"
		System.out.println(t1.getType("titulo")); //devuelve Type.String
		System.out.println(t1.getType("anno")); //devuelve Type.Long
		Interprete i1= new Interprete();
		i1.setId((long) 1); //simulamos que la base de datos le dio el id 1 al autor
		try {
			i1.setProperty("apellidos", "Cervantes");
		} catch (PropertyNoValida e) {}
		System.out.println(i1.getApellidos()); //devolver� "Cervantes"
		d1.setInterprete(i1.getId());

	}
}
