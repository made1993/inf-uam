package pruebas;
import java.util.*;

import base.Index;

public class PruebaIndice {

	public static void main(String[] args) {
		Index indice = new Index();
		Set<Long> set = new HashSet<Long>();
		Iterator<Long> it;
		
		indice.add("a", 1L);
		indice.add("b", 2L);
		indice.add("c", 3L);
		indice.add("d", 4L);
		indice.add("e", 5L);
		indice.add("f", 6L);
		indice.add("g", 7L);
		indice.add("h", 8L);

		set = (Set<Long>) indice.search("d", "f");
		
		it = set.iterator();
		while(it.hasNext()){
			System.out.println(it.next().toString());
		}
	}

}
