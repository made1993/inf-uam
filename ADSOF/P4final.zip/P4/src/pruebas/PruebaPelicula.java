package pruebas;

import exceptions.PropertyNoValida;
import interfaces.ITypeDescriptor;
import tienda.Director;
import tienda.Pelicula;

public class PruebaPelicula {
	public static void main(String[] args) {
		Pelicula p1= new Pelicula();
		p1.setTitulo("El Peligro");
		String titulo=(String) p1.getProperty("titulo"); //devuelve "El Peligro"
		System.out.println(titulo);
		ITypeDescriptor t1= Pelicula.getDescriptor(); //Ejemplo de m�todo para obtener el descriptor
		//Nota: Se deja a criterio del alumno la mejor forma de crear y obtener los descriptores
		System.out.println(t1.getName()); //devuelve "Libro"
		System.out.println(t1.getType("titulo")); //devuelve Type.String
		System.out.println(t1.getType("genero")); //devuelve Type.String
		Director d1= new Director();
		d1.setId((long) 1); //simulamos que la base de datos le dio el id 1 al director
		try {
			d1.setProperty("apellidos", "Cervantes");
		} catch (PropertyNoValida e) {}
		System.out.println(d1.getApellidos()); //devolver� "Cervantes"
		p1.setDirector(d1.getId());

	}
}
