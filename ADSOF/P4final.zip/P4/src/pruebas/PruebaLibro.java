package pruebas;

import exceptions.PropertyNoValida;
import tienda.Autor;
import tienda.Libro;
import interfaces.ITypeDescriptor;

public class PruebaLibro {

	public static void main(String[] args) {
		Libro l1= new Libro();
		l1.setTitulo("El Quijote");
		String titulo=(String) l1.getProperty("titulo"); //devuelve "El Quijote"
		System.out.println(titulo);
		ITypeDescriptor t1= Libro.getDescriptor(); //Ejemplo de m�todo para obtener el descriptor
		//Nota: Se deja a criterio del alumno la mejor forma de crear y obtener los descriptores
		System.out.println(t1.getName()); //devuelve "Libro"
		System.out.println(t1.getType("titulo")); //devuelve Type.String
		System.out.println(t1.getType("autor")); //devuelve Type.Long, ya que libro guarda el id del autor
		Autor a1= new Autor();
		a1.setId((long) 1); //simulamos que la base de datos le dio el id 1 al autor
		try {
			a1.setProperty("apellidos", "Cervantes");
		} catch (PropertyNoValida e) {}
		System.out.println(a1.getApellidos()); //devolver� "Cervantes"
		l1.setAutor(a1.getId());

	}

}
