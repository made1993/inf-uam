/**
 * 
 */
package interfaces;

import java.util.Collection;

import typeDescriptors.TypeDescriptor;
import base.Entity;

/**
 * @author Roberto
 *
 */
public interface IDAO{
	//Registra un nuevo tipo en la base de datos
	public void registerType(TypeDescriptor t);
	//Lee el objeto de la base de datos, o de cache, si se encuentra en memoria
	public Entity getEntity(String type, Long id);
	//Actualiza la entidad, asign�ndole un ID si este era null, y devuelve el ID
	public long updateEntity(Entity e);
	//Elimina la entidad
	public void delete(Entity e);
	//Busca las entidades que tengan el valor indicado
	public Collection<Long> search(String type, String property, Object value);
	//Devuelve la lista de entidades que tienen la propiedad property, entre el valor from y to
	//Si from o to son null, listar� desde el principio, o hasta el final, respectivamente
	//En el caso de que ambos sean null, listar� todas las entidades, ordenadas por property
	public Collection<Long> search(String type, String property, Object from, Object to);
}