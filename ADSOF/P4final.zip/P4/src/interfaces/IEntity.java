/**
 * 
 */
package interfaces;

import exceptions.PropertyNoValida;

/**
 * @author Roberto
 *
 */
public interface IEntity{
	//Id �nico para cada entidad del mismo tipo de datos. Null si no se ha guardado a�n
	public Long getId();
	public void setId(Long id); //Este m�todo solo lo usar� la base de datos, para asignar el id
	public String getType(); //Nombre del tipo de datos
	public Object getProperty(String property); //Obtiene el valor de una propiedad
	public void setProperty(String property, Object value) throws PropertyNoValida; //Modifica el valor de una propiedad
	}
