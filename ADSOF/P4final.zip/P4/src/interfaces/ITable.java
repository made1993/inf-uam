package interfaces;

import java.util.Collection;
import base.Entity;

public interface ITable{
	//Devuelve el tipo de dato para el que se ha creado la tabla
	public ITypeDescriptor getType();
	//Lee el objeto de la tabla y lo convierte en una Entity
	public Entity getEntity(Long id);
	//Actualiza la entidad y los �ndices, asign�ndole un ID si este era null, y devuelve el ID
	//Nota: La entidad se puede asumir que es del tipo de la tabla
	public long updateEntity(Entity e);
	//Elimina la entidad, si existe, actualizando los �ndices si es necesario
	public void delete(Entity e);
	//Busca las entidades que tengan el valor indicado
	public Collection<Long> search(String property, Object value);
	//Devuelve la lista de entidades que tienen la propiedad property, entre el valor from y to
	//Si from o to son null, listar� desde el principio, o hasta el final, respectivamente
	//En el caso de que ambos sean null, listar� todas las entidades, ordenadas por property
	public Collection<Long> search(String property, Object from, Object to);
}