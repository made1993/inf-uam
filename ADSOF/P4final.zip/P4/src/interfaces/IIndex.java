package interfaces;

import java.util.Collection;

public interface IIndex {
		//Relaciona value con key. Puede haber varios valores relacionados con un mismo objeto key
		void add (Object key, Long value);
		//Elimina la relaci�n entre value y key
		void delete(Object key, Long value);
		//Lista los valores relacionados con key
		Collection<Long> search(Object key);
		//Devuelve la lista de valores desde from a to
		//Si from o to son null, listar� desde el principio, o hasta el final, respectivamente
		//En el caso de que ambos sean null, listar� todos los valores del �ndice
		Collection<Long> search(Object from, Object to);

}
