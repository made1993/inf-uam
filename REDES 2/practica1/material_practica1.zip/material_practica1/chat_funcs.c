#include <glib.h>
#include <stdlib.h>
#include "chat.h"

void connectClient(void)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void disconnectClient(void)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void topicProtect(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void externMsg(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void secret(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void guests(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void privated(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void moderated(gboolean state)
{
	errorWindow("Función no implementada");
	errorText("Función no implementada");
}

void newText (const char *msg)
{
	errorText("Función no implementada");
}


