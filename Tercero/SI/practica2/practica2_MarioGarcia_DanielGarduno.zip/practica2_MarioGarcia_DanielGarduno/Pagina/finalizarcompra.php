<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	
	<div id="login">
		<?php 
			session_start();
			$usuario=$_SESSION['usuario'];
			if($usuario != null) echo '<br>'.$usuario.'<form action="logout.php"><input type="submit" value="Salir"></form>';
			else{
				echo '<form action="login.php"><input type="submit" value="Login"></form>';
				echo '<form action="registrop.php"><input type="submit" value="Registrarse"></form>';
			}
		?>
		</div>
		<div id="cabecera"><a href="index.php"><h1>Alquiler</h1></div>	

		<div id="mlateral"><h2>
			<h2><a href="busquedap.php">Busqueda</a></h2>
			<h2><a href="busqueda.php">Catalogo</a></h2>
			<h2><a href="historial.php">Historial</a></h2>
		</div> 
	<div id="contenido">
	<?php 
		session_start();
		$usuario=$_SESSION['usuario'];
		$carr = $_SESSION['carr'];
		$count = $_SESSION['count'];
		$ruta=$_SERVER['DOCUMENT_ROOT']. '/usuarios/' . $usuario."/historial.xml";
		if($usuario == null){
			echo "Necesitas iniciar sesion o registrarte en caso de que no tengas cuenta";
			echo '<form action="login.php"><input type="submit" value="Login"></form>';
			echo '<form action="registro.html"><input type="submit" value="Registrarse"></form>';
		}
		else{
			if (!(file_exists($ruta))){
				$xml = new DOMDocument('1.0', 'UTF-8');

				$xml_peliculas = $xml->createElement("peliculas");
				$xml->appendChild( $xml_peliculas );
				for($i=0; $i<$count;$i++){
					$xml_pelicula = $xml->createElement("pelicula",$carr[$i][0]); 
					$xml_peliculas->appendChild( $xml_pelicula );
				}
				echo 'La compra se realizo con exito';

			}
			else{
				$xml = new DOMDocument('1.0', 'UTF-8');
				$xml->load($ruta);
				foreach($xml->getElementsByTagName ('peliculas') as $xml_pelis){
					for($i=0; $i<$count;$i++){
						$xml_pelicula = $xml->createElement("pelicula",$carr[$i][0]); 
						$xml_pelis->appendChild( $xml_pelicula );
				}
				
				echo 'La compra se realizo con exito';
			}
		}
			$xml->save($ruta);
			chmod($ruta,0777);
		}
		$_SESSION['carr']=null;
		$_SESSION['count']=null;
	?>
	</div>

	<div id="ppagina"><?php echo date("d-m-Y H:i:s"); ?></div>
</body>
</html>
