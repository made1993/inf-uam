<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	
	<div id="login">
		<?php 
			session_start();
			$usuario=$_SESSION['usuario'];
			if($usuario != null) echo '<br>'.$usuario.'<form action="logout.php"><input type="submit" value="Salir"></form>';
			else{
				echo '<form action="login.php"><input type="submit" value="Login"></form>';
				echo '<form action="registrop.php"><input type="submit" value="Registrarse"></form>';
			}
		?>
		</div>
		<div id="cabecera"><a href="index.php"><h1>Alquiler</h1></div>	

		<div id="mlateral"><h2>
			<h2><a href="busquedap.php">Busqueda</a></h2>
			<h2><a href="busqueda.php">Catalogo</a></h2>
			<h2><a href="historial.php">Historial</a></h2>
		</div> 
	<div id="contenido">
	<?php
		session_start();
		$nombre=$_POST['nombre'];
		$pass=$_POST['password'];
		$directorio = $_SERVER['DOCUMENT_ROOT'] . '/usuarios/' . $nombre . '/datos.dat'; 
		// Open a known directory, and proceed to read its contents
		
		if(file_exists($directorio)==true){
			if(($fh = fopen($directorio,'r'))!=false){
				$bufer=fgets($fh);
				$bufer=fgets($fh);
				if((strcmp($bufer, md5($pass)."\n"))==0){
					$_SESSION['usuario']=$nombre;
					closedir($directorio);
					echo "Bienvendio ".$nombre;
				}
				else{
					$_SESSION['error']='password';
					closedir($directorio);
					header('Location: error.php');
				}
			}
		}else if(file_exists($directorio)!=true){
			closedir($directorio);
			$_SESSION['error']='login';
			header('Location: error.php');
		}
	?>

	</div>
	<div id="ppagina"><?php echo date("d-m-Y H:i:s"); ?></div>
</body>
</html>

