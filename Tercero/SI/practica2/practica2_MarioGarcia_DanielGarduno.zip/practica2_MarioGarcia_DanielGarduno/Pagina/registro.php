<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		
	</head>
	<body>
		<div id="login">
		<?php 
			session_start();
			$usuario=$_SESSION['usuario'];
			if($usuario != null) echo '<br>'.$usuario.'<form action="logout.php"><input type="submit" value="Salir"></form>';
			else{
				echo '<form action="login.php"><input type="submit" value="Login"></form>';
				echo '<form action="registrop.php"><input type="submit" value="Registrarse"></form>';
			}
		?>
		</div>
		<div id="cabecera"><a href="index.php"><h1>Alquiler</h1></div>	

		<div id="mlateral"><h2>
			<h2><a href="busquedap.php">Busqueda</a></h2>
			<h2><a href="busqueda.php">Catalogo</a></h2>
			<h2><a href="historial.php">Historial</a></h2>
		</div>  

		<div id="contenido">
			<?php
			$nombre=$_POST['name'];
			$pass=$_POST['pass'];
			$passc=$_POST['passc'];
			$mail=$_POST['mail'];
			$card=$_POST['card'];
			$dir=$_SERVER['DOCUMENT_ROOT']."/usuarios";
			if (is_dir($dir)==TRUE){
				if (is_dir($dir."/".$nombre)==TRUE ){
						printf("ya existe el usuario");
				}
				else{
					$dir=$dir."/".$nombre;
					mkdir($dir, 0777);
					chmod($dir,0777);
					opendir($dir);
					$fl=fopen($dir."/datos.dat","w");
					fprintf($fl, "%s\n", $nombre);
					fprintf($fl, "%s\n", md5($pass));
					fprintf($fl, "%s\n", $mail);
					fprintf($fl, "%s\n", $card);
					printf("el usuario %s se registro correctamente\n", $nombre);
				}
			}
			else{
				
			mkdir($dir,0777);
			chmod($dir,0777);
			$dir=$dir."/".$nombre;
			mkdir($dir, 0777);
			chmod($dir, 0777);
			opendir($dir);
			$fl=fopen($dir."/datos.dat","w");
			fprintf($fl, "%s\n", $nombre);
			fprintf($fl, "%s\n", md5($pass));
			fprintf($fl, "%s\n", $mail);
			fprintf($fl, "%s\n", $card);
			printf("el usuario %s se registro correctamente\n", $nombre);
				
			}
			?>
		</div>
		<div id="ppagina"><?php echo date("d-m-Y H:i:s"); ?></div>
	</body>
</html>
