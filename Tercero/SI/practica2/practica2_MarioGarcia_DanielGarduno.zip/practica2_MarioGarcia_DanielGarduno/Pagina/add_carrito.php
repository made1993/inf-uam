<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html xsl:version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		<?php
		session_start();
		$titulo=$_GET['titulo'];
		$precio=$_GET['precio'];
		$precio1=$_GET['precio1'];
		$titulo1=$_GET['titulo1'];
		$categoria1=$_GET['categoria1'];
		$count=$_SESSION['count'];
		

		
		if (($titulo==null)||($precio==null)){
			header('Location: error.php');
		}
		if(($count==null)||($count==0)){
			$count = 0;			
		}
		else{
			$carr = $_SESSION['carr'];
		}
		$carr[$count][0]=$titulo;
		$carr[$count][1]=$precio;
		$count++;
		$_SESSION['carr']=$carr;
		$_SESSION['count']=$count;
		$_SESSION['senable']=1;	
		$_SESSION['precio1']=$precio1;
		$_SESSION['titulo1']=$titulo1;
		$_SESSION['categoria1']=$categoria1;
		header('Location: busqueda.php');
		?>
	</head>
</html>