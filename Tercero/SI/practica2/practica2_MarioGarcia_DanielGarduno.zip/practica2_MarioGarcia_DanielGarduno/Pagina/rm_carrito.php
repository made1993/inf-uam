<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html xsl:version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		<?php
		session_start();
		$titulo=$_GET['titulo'];
		$precio=$_GET['precio'];
		$precio1=$_GET['precio1'];
		$titulo1=$_GET['titulo1'];
		$categoria1=$_GET['categoria1'];
		$count=$_SESSION['count'];
		
		if (($titulo==null)||($precio==null)){
			header('Location: error.php');
		}
		echo $count;
		if(($count==null)||($count==0)){
			header('Location: busqueda.php');
		}
		else{
			$carr = $_SESSION['carr'];
		}
		for($i=0;$i<$count;$i++){
			if(strcmp($carr[$i][0],$titulo)==0){
				for(;$i<$count;$i++){
					if($i+1==$count){
						$carr[$i]=null;
					}
					else{
						$carr[$i]=$carr[$i+1];	
					}

				}
				array_pop($carr);
				$count--;
				break;
			}
		}

		$_SESSION['count']=$count;	
		$_SESSION['carr']=$carr;
		$_POST['precio1']=$precio1;
		$_POST['titulo1']=$titulo1;
		$_POST['categoria1']=$categoria1;
		header('Location: busqueda.php');
		?>
	</head>
</html>