<?php
   echo "Fecha del dia de hoy: ". date();
?>
 
