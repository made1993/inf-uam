
<html xsl:version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		
	</head>
	<body>
		<div id="login">
		<?php 
			session_start();
			$usuario=$_SESSION['usuario'];
			if($usuario != null) echo '<br>'.$usuario.'<form action="logout.php"><input type="submit" value="Salir"></form>';
			else{
				echo '<form action="login.php"><input type="submit" value="Login"></form>';
				echo '<form action="registrop.php"><input type="submit" value="Registrarse"></form>';
			}
		?>
		</div>
		<div id="cabecera"><a href="index.php"><h1>Alquiler</h1></div>	

		<div id="mlateral"><h2>
			<h2><a href="busquedap.php">Busqueda</a></h2>
			<h2><a href="busqueda.php">Catalogo</a></h2>
			<h2><a href="historial.php">Historial</a></h2>
		</div> 
		<div id="contenido">
			<?php
				session_start();
				$titulo=$_POST['titulo1'];
				$categoria=$_POST['categoria1'];
				$precio=$_POST['precio1'];
				if($_SESSION['senable']==1){
					$precio=$_SESSION['precio1'];
					$categoria=$_SESSION['categoria1'];
					$titulo=$_SESSION['titulo1'];
				}
				$count=$_SESSION['count'];
				if($count==null){
					$count=0;
				}
				$_SESSION['senable']=0;
				echo 'Productos en el carrito:'.$count;
				if($count >0)
				echo '<form action="finalizarcompra.php"> <input type="submit" value="Pagar"></form>';
				echo '<br></br>';
				if (file_exists('datos.xml')) {
				    $xml = simplexml_load_file('datos.xml');
				    foreach($xml->peliculas->pelicula as $pelicula){

						$array=array($count=>array("titulo"=>$pelicula->titulo,"precio"=> $pelicula->precio,"categoria"=>$pelicula->categoria));
						$img=$pelicula->img;
				    	if(($titulo!=null)&&($array[$count]["titulo"]==$titulo)){
				    		if(($categoria!=null)&&($array[$count]["categoria"]==$categoria)){
					    		if(($precio!=null)&&($array[$count]["precio"]==$precio)){
					    			echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["precio"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';

					    		}
					    		elseif ($precio==null) {
					    			echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';

					    		}
				    		}
				    		elseif ($categoria==null) {
				    			if(($precio!=null)&&($array[$count]["precio"]==$precio)){
				    				echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';
					    		}
					    		elseif ($precio==null) {
					    			echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';
					    		}
				    		}
				    	}
				    	elseif ($titulo==null) {
				    		if(($categoria!=null)&&($array[$count]["categoria"]==$categoria)){
				    			if(($precio!=null)&&($array[$count]["precio"]==$precio)){
				    				echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';
					    		}
					    		elseif ($precio==null) {
					    			echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    			echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';
					    		}
				    		}
				    		elseif ($categoria==null) {
				    			if(($precio!=null)&&($array[$count]["precio"]==$precio)){
				    				echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
					    				echo '<form action="add_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="submit" name="submit" value="Comprar">';
					    				echo '</form>';
					    				echo '<form action="rm_carrito.php" method="get">';
					    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
					    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
					    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
					    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
					    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
					    				echo '<input type="submit" name="submit" value="Quitar">';
					    				echo '<br></br></form>';
					    			
					    		}
					    		elseif ($precio==null) {
					    			echo "<img src=".$img.">";
					    			echo'<br></br>';
					    			printf("Titulo:%s. PVP:%s. Fecha:%s",$array[$count]["titulo"],$array[$count]["precio"],$pelicula->fecha);
					    			echo '<br></br>';
				    				echo '<form action="add_carrito.php" method="get">';
				    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
				    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
				    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
				    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
				    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
				    				echo '<input type="submit" name="submit" value="Comprar">';
				    				echo '</form>';
				    				echo '<form action="rm_carrito.php" method="get">';
				    				echo '<input type="hidden" name="titulo" value="'.$array[$count]["titulo"].'">';
				    				echo '<input type="hidden" name="titulo1" value="'.$titulo.'">';
				    				echo '<input type="hidden" name="categoria1" value="'.$categoria.'">';
				    				echo '<input type="hidden" name="precio1" value="'.$precio.'">';
				    				echo '<input type="hidden" name="precio" value="'.$array[$count]["precio"].'">';
				    				echo '<input type="submit" name="submit" value="Quitar">';
				    				echo '<br></br></form>';
					    			
					    		}
				    		}
				    	}
				    }
				} 
			?>
		</div>
		<div id="ppagina"><?php echo date("d-m-Y H:i:s"); ?></div>
	</body>
</html>
