<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html xsl:version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		<?php
		session_start();
		$_SESSION['carr']=null;
		$_SESSION['count']=null;
		$_SESSION['senable']=null;	
		$_SESSION['precio1']=null;
		$_SESSION['titulo1']=null;
		$_SESSION['categoria1']=null;
		$_SESSION['usuario']=null;
		header('Location: index.php');
		?>
	</head>
</html>