/**
 * Clase Mago
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public class Mago extends Explorador {

	private int poder;

	public Mago(String nombre, int energia, Posada iniPos, int poder) {
		super(nombre, energia, iniPos);
		this.poder = poder;
	}
	
	public boolean puedeRecorrerCamino(Camino c) {
		if (c == null || c.esTrampa()==true)
			return false;
		if (this.getEnergia() > c.costeReal())
			return true;
		return false;
	}

	public int getPoder() {
		return poder;
	}

	public String toString() {
		return "Mago: " + this.getNombre() + " (e:" + this.getEnergia()
				+ ") en " + this.getPos().getNombre();
	}

}
