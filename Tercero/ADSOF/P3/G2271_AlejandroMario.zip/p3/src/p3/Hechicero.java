/**
 * Clase Hechicero
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public class Hechicero extends Mago {

	/**
	 * Constructor de la clase Hechicero
	 * @param nombre Nombre del Hechicero
	 * @param energia Energia del Hechicero
	 * @param iniPos Posicion inicial del Hechicero
	 * @param poder Poder del Hechicero
	 */
	public Hechicero(String nombre, int energia, Posada iniPos, int poder) {
		super(nombre, energia, iniPos, poder);
	}

	/**
	 * Metodo que indica si el hechicero puede alojarse en una posada.
	 * @param p Posada en la que nos podiramos alojar.
	 * @return Boleano con el valor de si nos podemos alojar o no.
	 */
	@Override
	public boolean puedeAlojarseEn(Posada p) {

		if (p.getLuz().getNumero() <= 2
				|| (p.getLuz().getNumero() > 2 && this.getPoder() >= p.getLuz()
						.getNumero())) {
			return true;
		}
		return false;
	}
	
	/**
	 * Metodo que convierte el objeto a formato String.
	 * @return String con la informacion del explorador.
	 */
	public String toString() {
		return "Hechicero: " + this.getNombre() + " (e:" + this.getEnergia()
				+ ") en " + this.getPos().getNombre();
	}
}
