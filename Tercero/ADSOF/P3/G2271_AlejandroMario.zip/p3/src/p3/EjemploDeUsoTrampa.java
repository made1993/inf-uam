/**
 * Prueba de las clases Explorador, Posada, Camino y Trampa
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public class EjemploDeUsoTrampa {

	public static void main(String[] args) {

		Posada solana = new Posada("Solana", 1);
		Posada romeral = new Posada("Romeral", 5);
		Posada tomelloso = new Posada("Tomelloso"); // por defecto enerRec = 2
		Explorador sancho = new Explorador("Sancho", 100, solana);
		solana.addCamino(new Trampa(solana, romeral, 20, 1, 3));
		romeral.addCamino(new Camino(romeral, tomelloso, 11));
		System.out.println(sancho);
		sancho.recorre(romeral); // ira a romeral si la trampa no se activa
		System.out.println(sancho); // si va a romeral: 65 = 100 - (20*1 + 20)+ 5
		sancho.recorre(romeral.getCamino(tomelloso));
		System.out.println(sancho);
	}

}
