/**
 * Clase Hada
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public class Hada extends Mago {

	/**
	 * Constructor de la clase Hada
	 * @param nombre Nombre de la Hada
	 * @param energia Energia de la Hada
	 * @param iniPos POsicion inicial de la Hada
	 * @param poder Poder de la hada
	 */
	public Hada(String nombre, int energia, Posada iniPos, int poder) {
		super(nombre, energia, iniPos, poder);
	}

	/**
	 * Metodo que indica si la hada puede alojarse en una posada.
	 * @param p Posada en la que nos podiramos alojar.
	 * @return Boleano con el valor de si nos podemos alojar o no.
	 */
	@Override
	public boolean puedeAlojarseEn(Posada p) {
		
		if (p.getLuz().getNumero() > 3  ) {
			return true;
		}
		return false;
	}
	
	/**
	 * Metodo que convierte el objeto a formato String.
	 * @return String con la informacion del explorador.
	 */
	public String toString() {
		return "Hada: " + this.getNombre() + " (e:" + this.getEnergia()
				+ ") en " + this.getPos().getNombre();
	}
	
}
