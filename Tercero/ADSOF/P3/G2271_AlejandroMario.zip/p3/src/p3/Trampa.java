/**
 * Clase Trampa
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

import p3.Posada;

public class Trampa extends Camino {

	private int factor_coste_extra;
	private int prob_ret_obligado;

	/**
	 * Constructor de la clase Trampa
	 * 
	 * @param origen
	 *            Posada origen.
	 * @param destino
	 *            Posada Destino.
	 * @param energia
	 *            Energia que se pierde al recorrer el camino.
	 * @param factor_c_ext
	 *            Factor extra que cuesta atravesar la trampa
	 * @param prob_r_oblig
	 *            Probabilidad de caer en la trampa (del 1 al 10)
	 */
	public Trampa(Posada origen, Posada destino, int energia, int factor_c_ext,
			int prob_r_oblig) {
		super(origen, destino, energia);
		this.factor_coste_extra = factor_c_ext;
		this.prob_ret_obligado = prob_r_oblig;
	}

	/**
	 * Coste especial de recorrer el camino.
	 * 
	 * @return Entero con el coste de recorrer el camino.
	 */
	@Override
	public int costeEspecial() {
		return this.factor_coste_extra * this.getEnergia();
	}

	/**
	 * Retorna el factor coste extra.
	 * 
	 * @return Un int con el valor del factor.
	 */
	public int getFactor_coste_extra() {
		return factor_coste_extra;
	}

	/**
	 * Retorna la probabilidad de retorno obligatorio.
	 * 
	 * @return Un int con la probabilidad.
	 */
	public int getProb_ret_obligado() {
		return prob_ret_obligado;
	}

	/**
	 * Retorna la posada de destino
	 * 
	 * @return Una posada con el valor del destino de la trampa si la
	 *         probabilidad de retorno obligatorio es mayor que el valor
	 *         aleatorio y con la posada de origen si esa probabilidad es menor
	 *         que el valor aleatorio.
	 */
	@Override
	public Posada getDestino() {

		int valorEntero = (int) Math.floor(Math.random() * (10 - 0 + 1) + 0);

		if (valorEntero <= this.getProb_ret_obligado()) {
			return this.getOrigen();
		}

		return super.getDestino();
	}

	/**
	 * Metodo que devuelve si es una trampa.
	 * 
	 * @return Devuelve TRUE.
	 */
	@Override
	public boolean esTrampa() {
		return true;
	}

	/**
	 * Devuelve los valores del objeto como una cadena.
	 * 
	 * @return String con el valor del objeto convertido a cadena.
	 */
	public String toString() {
		return "Trampa: (" + this.getOrigen().getNombre() + "--"
				+ this.getEnergia() + "-->" + this.getOrigen().getNombre();
	}
}
