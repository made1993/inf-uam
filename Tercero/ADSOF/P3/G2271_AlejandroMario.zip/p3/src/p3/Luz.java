/**
 * Clase Enumerado Luz
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public enum Luz {
	
	DIABOLICA(0),
	NEGRA(1),
	TENEBROSA(2), 
	GRIS(3),
	CLARA(4),
	BLANCA(5),
	DIVINA(6);

	private int numero;
	 
	/**
	 * Constructor de la clase Luz
	 * @param numero Valor numerico de la luz
	 */
    Luz(int numero) {
        this.numero = numero;
    }
 
    /**
     * Retorna el valor numerico de la luz
     * @return Entero con el valor de la luz
     */
    public int getNumero() {
        return numero;
    }

}
