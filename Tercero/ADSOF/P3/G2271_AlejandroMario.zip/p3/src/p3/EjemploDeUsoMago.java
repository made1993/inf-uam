/**
 * Prueba de las clases Mago, Hechicero y Hada
 * @author Alejandro Antonio Martin Almansa
 * @author Mario Garcia Roque
 *
 */
package p3;

public class EjemploDeUsoMago {

	// Se crean 3 personajes que ir�n recorriendo los caminos y trampas seg�n su
	// energ�a y sus permisos.
	
	public static void main(String[] args) {

		Posada solana = new Posada("Solana", 1); // luz blanca por defecto
		Posada romeral = new Posada("Romeral", 5, Luz.TENEBROSA);
		Posada tomelloso = new Posada("Tomelloso", 5, Luz.NEGRA);
		Posada pisador = new Posada("Nevadalia", 10, Luz.BLANCA);
		Posada comarca = new Posada("Toboso", 15, Luz.DIVINA);

		Explorador sancho = new Explorador("Sancho", 50, solana);
		Explorador gandalf = new Hechicero("Gandalf", 100, pisador, 5);
		Explorador arwen = new Hada("Arwen", 150, romeral, 20);

		solana.addCamino(new Trampa(solana, romeral, 15, 1, 3));
		romeral.addCamino(new Camino(romeral, pisador, 5));
		romeral.addCamino(new Camino(romeral, solana, 10));
		tomelloso.addCamino(new Camino(tomelloso, comarca, 10));
		pisador.addCamino(new Camino(pisador, tomelloso, 10));
		pisador.addCamino(new Camino(pisador, solana, 10));

		/**
		 * Va a poder ir a romeral si no se activa la trampa. Podr� ir a pisador
		 * si llega a romeral. No podr� ir a solana porque no hay camino entre
		 * pisador y solana.
		 */
		System.out.println(sancho);
		sancho.recorre(romeral, pisador, solana);
		System.out.println(sancho);

		/**
		 * Podra ir a tomelloso, pero no a comarca por poder insuficiente.
		 */
		System.out.println(gandalf);
		gandalf.recorre(tomelloso, comarca);
		System.out.println(gandalf);

		/**
		 * Podra ir a solana, pero no a romeral porque no pueden pasar por una
		 * trampa.
		 * */
		System.out.println(arwen);
		romeral.cambiarLuz(Luz.DIVINA);
		arwen.recorre(solana, romeral);
		System.out.println(arwen);

	}

}
