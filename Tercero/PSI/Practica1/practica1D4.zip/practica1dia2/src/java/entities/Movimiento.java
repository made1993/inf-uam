/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author e280635
 */
@Entity
@Table(name = "movimiento")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Movimiento.findAll", query = "SELECT m FROM Movimiento m"),
    @NamedQuery(name = "Movimiento.findByFila", query = "SELECT m FROM Movimiento m WHERE m.fila = :fila"),
    @NamedQuery(name = "Movimiento.findByColumna", query = "SELECT m FROM Movimiento m WHERE m.columna = :columna"),
    @NamedQuery(name = "Movimiento.findByNMovimiento", query = "SELECT m FROM Movimiento m WHERE m.nMovimiento = :nMovimiento")})
public class Movimiento implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fila")
    private int fila;
    @Basic(optional = false)
    @NotNull
    @Column(name = "columna")
    private int columna;
    @Id
    @SequenceGenerator(name="movimiento_n_movimiento_seq", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="movimiento_n_movimiento_seq")
    
    @Basic(optional = false)
    @Column(name = "n_movimiento")
    private Integer nMovimiento;
    @JoinColumn(name = "n_partida", referencedColumnName = "n_partida")
    @ManyToOne
    private Partida nPartida;

    public Movimiento() {
    }

    public Movimiento(Integer nMovimiento) {
        this.nMovimiento = nMovimiento;
    }

    public Movimiento(Integer nMovimiento, int fila, int columna) {
        this.nMovimiento = nMovimiento;
        this.fila = fila;
        this.columna = columna;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public Integer getNMovimiento() {
        return nMovimiento;
    }

    public void setNMovimiento(Integer nMovimiento) {
        this.nMovimiento = nMovimiento;
    }

    public Partida getNPartida() {
        return nPartida;
    }

    public void setNPartida(Partida nPartida) {
        this.nPartida = nPartida;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nMovimiento != null ? nMovimiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movimiento)) {
            return false;
        }
        Movimiento other = (Movimiento) object;
        if ((this.nMovimiento == null && other.nMovimiento != null) || (this.nMovimiento != null && !this.nMovimiento.equals(other.nMovimiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Movimiento[ nMovimiento=" + nMovimiento + " ]";
    }
    
}
