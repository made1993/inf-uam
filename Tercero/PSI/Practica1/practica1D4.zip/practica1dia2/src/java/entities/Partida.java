/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author e280635
 */
@Entity
@Table(name = "partida")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Partida.findAll", query = "SELECT p FROM Partida p"),
    @NamedQuery(name = "Partida.findByNPartida", query = "SELECT p FROM Partida p WHERE p.nPartida = :nPartida"),
    @NamedQuery(name = "Partida.findByColorUsuario", query = "SELECT p FROM Partida p WHERE p.colorUsuario = :colorUsuario"),
    @NamedQuery(name = "Partida.findByEstado", query = "SELECT p FROM Partida p WHERE p.estado = :estado")})
public class Partida implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="partida_n_partida_seq", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="partida_n_partida_seq")
    
    @Basic(optional = false)
    @Column(name = "n_partida")
    private Integer nPartida;
    @Basic(optional = false)
    @NotNull
    @Column(name = "color_usuario")
    private int colorUsuario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estado")
    private int estado;
    @JoinColumn(name = "id_usuario", referencedColumnName = "id_usuario")
    @ManyToOne(optional = false)
    private Usuario idUsuario;
    @OneToMany(mappedBy = "nPartida")
    private Collection<Movimiento> movimientoCollection;

    public Partida() {
    }

    public Partida(Integer nPartida) {
        this.nPartida = nPartida;
    }

    public Partida(Integer nPartida, int colorUsuario, int estado) {
        this.nPartida = nPartida;
        this.colorUsuario = colorUsuario;
        this.estado = estado;
    }

    public Integer getNPartida() {
        return nPartida;
    }

    public void setNPartida(Integer nPartida) {
        this.nPartida = nPartida;
    }

    public int getColorUsuario() {
        return colorUsuario;
    }

    public void setColorUsuario(int colorUsuario) {
        this.colorUsuario = colorUsuario;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Usuario getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Usuario idUsuario) {
        this.idUsuario = idUsuario;
    }

    @XmlTransient
    public Collection<Movimiento> getMovimientoCollection() {
        return movimientoCollection;
    }

    public void setMovimientoCollection(Collection<Movimiento> movimientoCollection) {
        this.movimientoCollection = movimientoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nPartida != null ? nPartida.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Partida)) {
            return false;
        }
        Partida other = (Partida) object;
        if ((this.nPartida == null && other.nPartida != null) || (this.nPartida != null && !this.nPartida.equals(other.nPartida))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Partida[ nPartida=" + nPartida + " ]";
    }
    
}
