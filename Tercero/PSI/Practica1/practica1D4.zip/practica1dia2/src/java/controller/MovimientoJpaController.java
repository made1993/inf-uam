/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import controller.exceptions.NonexistentEntityException;
import controller.exceptions.RollbackFailureException;
import entities.Movimiento;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Partida;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author e280635
 */
public class MovimientoJpaController implements Serializable {

    public MovimientoJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Movimiento movimiento) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin(); 
            em = getEntityManager();
            Partida NPartida = movimiento.getNPartida();
            if (NPartida != null) {
                NPartida = em.getReference(NPartida.getClass(), NPartida.getNPartida());
                movimiento.setNPartida(NPartida);
            }
            em.persist(movimiento);
            if (NPartida != null) {
                NPartida.getMovimientoCollection().add(movimiento);
                NPartida = em.merge(NPartida);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Movimiento movimiento) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Movimiento persistentMovimiento = em.find(Movimiento.class, movimiento.getNMovimiento());
            Partida NPartidaOld = persistentMovimiento.getNPartida();
            Partida NPartidaNew = movimiento.getNPartida();
            if (NPartidaNew != null) {
                NPartidaNew = em.getReference(NPartidaNew.getClass(), NPartidaNew.getNPartida());
                movimiento.setNPartida(NPartidaNew);
            }
            movimiento = em.merge(movimiento);
            if (NPartidaOld != null && !NPartidaOld.equals(NPartidaNew)) {
                NPartidaOld.getMovimientoCollection().remove(movimiento);
                NPartidaOld = em.merge(NPartidaOld);
            }
            if (NPartidaNew != null && !NPartidaNew.equals(NPartidaOld)) {
                NPartidaNew.getMovimientoCollection().add(movimiento);
                NPartidaNew = em.merge(NPartidaNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = movimiento.getNMovimiento();
                if (findMovimiento(id) == null) {
                    throw new NonexistentEntityException("The movimiento with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Movimiento movimiento;
            try {
                movimiento = em.getReference(Movimiento.class, id);
                movimiento.getNMovimiento();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The movimiento with id " + id + " no longer exists.", enfe);
            }
            Partida NPartida = movimiento.getNPartida();
            if (NPartida != null) {
                NPartida.getMovimientoCollection().remove(movimiento);
                NPartida = em.merge(NPartida);
            }
            em.remove(movimiento);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Movimiento> findMovimientoEntities() {
        return findMovimientoEntities(true, -1, -1);
    }

    public List<Movimiento> findMovimientoEntities(int maxResults, int firstResult) {
        return findMovimientoEntities(false, maxResults, firstResult);
    }

    private List<Movimiento> findMovimientoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Movimiento.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Movimiento findMovimiento(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Movimiento.class, id);
        } finally {
            em.close();
        }
    }

    public int getMovimientoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Movimiento> rt = cq.from(Movimiento.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    
    public Movimiento query1() {
        EntityManager em = getEntityManager();
        try {
            String sqlCommand = "select m from Movimiento m where m.nPartida.nPartida = 2 order by m.nMovimiento desc";
            Query q= em.createQuery(sqlCommand);
            q.setMaxResults(1);
            Movimiento m=(Movimiento)q.getSingleResult();
            
            return m;

        } finally {
            em.close();
        }
    }
    
}
