/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import controller.exceptions.NonexistentEntityException;
import controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Usuario;
import entities.Movimiento;
import entities.Partida;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author e280635
 */
public class PartidaJpaController implements Serializable {

    public PartidaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Partida partida) throws RollbackFailureException, Exception {
        if (partida.getMovimientoCollection() == null) {
            partida.setMovimientoCollection(new ArrayList<Movimiento>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Usuario idUsuario = partida.getIdUsuario();
            if (idUsuario != null) {
                idUsuario = em.getReference(idUsuario.getClass(), idUsuario.getIdUsuario());
                partida.setIdUsuario(idUsuario);
            }
            Collection<Movimiento> attachedMovimientoCollection = new ArrayList<Movimiento>();
            for (Movimiento movimientoCollectionMovimientoToAttach : partida.getMovimientoCollection()) {
                movimientoCollectionMovimientoToAttach = em.getReference(movimientoCollectionMovimientoToAttach.getClass(), movimientoCollectionMovimientoToAttach.getNMovimiento());
                attachedMovimientoCollection.add(movimientoCollectionMovimientoToAttach);
            }
            partida.setMovimientoCollection(attachedMovimientoCollection);
            em.persist(partida);
            if (idUsuario != null) {
                idUsuario.getPartidaCollection().add(partida);
                idUsuario = em.merge(idUsuario);
            }
            for (Movimiento movimientoCollectionMovimiento : partida.getMovimientoCollection()) {
                Partida oldNPartidaOfMovimientoCollectionMovimiento = movimientoCollectionMovimiento.getNPartida();
                movimientoCollectionMovimiento.setNPartida(partida);
                movimientoCollectionMovimiento = em.merge(movimientoCollectionMovimiento);
                if (oldNPartidaOfMovimientoCollectionMovimiento != null) {
                    oldNPartidaOfMovimientoCollectionMovimiento.getMovimientoCollection().remove(movimientoCollectionMovimiento);
                    oldNPartidaOfMovimientoCollectionMovimiento = em.merge(oldNPartidaOfMovimientoCollectionMovimiento);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Partida partida) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Partida persistentPartida = em.find(Partida.class, partida.getNPartida());
            Usuario idUsuarioOld = persistentPartida.getIdUsuario();
            Usuario idUsuarioNew = partida.getIdUsuario();
            Collection<Movimiento> movimientoCollectionOld = persistentPartida.getMovimientoCollection();
            Collection<Movimiento> movimientoCollectionNew = partida.getMovimientoCollection();
            if (idUsuarioNew != null) {
                idUsuarioNew = em.getReference(idUsuarioNew.getClass(), idUsuarioNew.getIdUsuario());
                partida.setIdUsuario(idUsuarioNew);
            }
            Collection<Movimiento> attachedMovimientoCollectionNew = new ArrayList<Movimiento>();
            for (Movimiento movimientoCollectionNewMovimientoToAttach : movimientoCollectionNew) {
                movimientoCollectionNewMovimientoToAttach = em.getReference(movimientoCollectionNewMovimientoToAttach.getClass(), movimientoCollectionNewMovimientoToAttach.getNMovimiento());
                attachedMovimientoCollectionNew.add(movimientoCollectionNewMovimientoToAttach);
            }
            movimientoCollectionNew = attachedMovimientoCollectionNew;
            partida.setMovimientoCollection(movimientoCollectionNew);
            partida = em.merge(partida);
            if (idUsuarioOld != null && !idUsuarioOld.equals(idUsuarioNew)) {
                idUsuarioOld.getPartidaCollection().remove(partida);
                idUsuarioOld = em.merge(idUsuarioOld);
            }
            if (idUsuarioNew != null && !idUsuarioNew.equals(idUsuarioOld)) {
                idUsuarioNew.getPartidaCollection().add(partida);
                idUsuarioNew = em.merge(idUsuarioNew);
            }
            for (Movimiento movimientoCollectionOldMovimiento : movimientoCollectionOld) {
                if (!movimientoCollectionNew.contains(movimientoCollectionOldMovimiento)) {
                    movimientoCollectionOldMovimiento.setNPartida(null);
                    movimientoCollectionOldMovimiento = em.merge(movimientoCollectionOldMovimiento);
                }
            }
            for (Movimiento movimientoCollectionNewMovimiento : movimientoCollectionNew) {
                if (!movimientoCollectionOld.contains(movimientoCollectionNewMovimiento)) {
                    Partida oldNPartidaOfMovimientoCollectionNewMovimiento = movimientoCollectionNewMovimiento.getNPartida();
                    movimientoCollectionNewMovimiento.setNPartida(partida);
                    movimientoCollectionNewMovimiento = em.merge(movimientoCollectionNewMovimiento);
                    if (oldNPartidaOfMovimientoCollectionNewMovimiento != null && !oldNPartidaOfMovimientoCollectionNewMovimiento.equals(partida)) {
                        oldNPartidaOfMovimientoCollectionNewMovimiento.getMovimientoCollection().remove(movimientoCollectionNewMovimiento);
                        oldNPartidaOfMovimientoCollectionNewMovimiento = em.merge(oldNPartidaOfMovimientoCollectionNewMovimiento);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = partida.getNPartida();
                if (findPartida(id) == null) {
                    throw new NonexistentEntityException("The partida with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Partida partida;
            try {
                partida = em.getReference(Partida.class, id);
                partida.getNPartida();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The partida with id " + id + " no longer exists.", enfe);
            }
            Usuario idUsuario = partida.getIdUsuario();
            if (idUsuario != null) {
                idUsuario.getPartidaCollection().remove(partida);
                idUsuario = em.merge(idUsuario);
            }
            Collection<Movimiento> movimientoCollection = partida.getMovimientoCollection();
            for (Movimiento movimientoCollectionMovimiento : movimientoCollection) {
                movimientoCollectionMovimiento.setNPartida(null);
                movimientoCollectionMovimiento = em.merge(movimientoCollectionMovimiento);
            }
            em.remove(partida);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Partida> findPartidaEntities() {
        return findPartidaEntities(true, -1, -1);
    }

    public List<Partida> findPartidaEntities(int maxResults, int firstResult) {
        return findPartidaEntities(false, maxResults, firstResult);
    }

    private List<Partida> findPartidaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Partida.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Partida findPartida(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Partida.class, id);
        } finally {
            em.close();
        }
    }

    public int getPartidaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Partida> rt = cq.from(Partida.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    public List<Integer> query1() {
        EntityManager em = getEntityManager();
        try {
            String sqlCommand = "select p.nPartida from Partida p where p.estado !='-1'";//select * from Partida where estado != -1;
            Query q= em.createQuery(sqlCommand);
            List<Integer> p = new ArrayList<Integer>();
            p = q.getResultList();
            
            return p;

        } finally {
            em.close();
        }
    }
    
}
