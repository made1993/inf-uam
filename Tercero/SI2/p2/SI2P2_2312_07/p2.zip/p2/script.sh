export J2EE_HOME=/usr/local/glassfish-4.0/glassfish/
cd P1-base
ant regenerar-bd
