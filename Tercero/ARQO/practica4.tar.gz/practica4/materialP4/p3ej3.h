#ifndef _P3EJ3_H_
#define _P3EJ3_H_
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include "arqo3.h"

void mult(num** a, num** b, num** c, int n);
void mult_t(num** a, num** b, num** c, int n);
void traspuesta(num**a, num**t, int n);

#endif
