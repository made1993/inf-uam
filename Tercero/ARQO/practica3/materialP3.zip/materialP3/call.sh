minsz=1
maxsz=2049
incr=512
size=1024
d=0
rm -r fast_dir
rm -r slow_dir
rm datoss.dat
rm datosf.dat
mkdir slow_dir
mkdir fast_dir
chmod 0777 slow_dir
chmod 0777 fast_dir
for ((d=1024;d<=1024;d=d+d));
do
	for i in $(seq $minsz $incr $maxsz)
	do
	valgrind --tool=cachegrind --I1=$d,1,64 --D1=$d,1,64 --LL=8388608,1,64 --cachegrind-out-file=slow_dir/$d\_$i.dat ./slow $i
	printf "$d\t$i" >>datoss.dat
	cg_annotate slow_dir/$d\_$i.dat | grep -i PROGRAM >> datoss.dat
	valgrind --tool=cachegrind --I1=$d,1,64 --D1=$d,1,64 --LL=8388608,1,64 --cachegrind-out-file=fast_dir/$d\_$i.dat ./fast $i
	printf "$d\t$i" >>datosf.dat
	cg_annotate fast_dir/$d\_$i.dat | grep -i PROGRAM  >>datosf.dat
	done
# usar cut -d " " -f columnas <file>
done
sed -i 's/,//g' datoss.dat
sed -i 's/,//g' datosf.dat

