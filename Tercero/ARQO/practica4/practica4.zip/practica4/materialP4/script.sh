make clean
make

