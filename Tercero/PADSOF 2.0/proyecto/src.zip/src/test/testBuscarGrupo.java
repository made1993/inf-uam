package test;

import java.util.ArrayList;

import grupo.*;
import mailUam.MailUam;

public class testBuscarGrupo {
	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		MailUam app = new MailUam();
		System.out.println("Imprimiendo app\n" + app.toString());

		System.out.println("Buscando grupo de adsof");

		ArrayList<Grupo> g = app.buscarGrupoLista("adsof");
		System.out.println("Resultado busqueda "+g.size());
		System.out.println("Buscando grupo");
		System.out.println(g);
		if (g.size()!=0) {
			System.out.println(app.crearSubGrupo("subsubsubprueba", false, null, g.get(0), null));
		}
		System.out.println("Imormiendo app");
		System.out.println(app);
		app.guardarUsuario();
		app.guardarGrupos();*/
		
		
		
	}
}
