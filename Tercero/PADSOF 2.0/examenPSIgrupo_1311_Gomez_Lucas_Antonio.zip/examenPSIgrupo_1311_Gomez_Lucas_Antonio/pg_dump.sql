--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: libro; Type: TABLE; Schema: public; Owner: alumnodb; Tablespace: 
--

CREATE TABLE libro (
    lid integer NOT NULL,
    nombrem text
);


ALTER TABLE public.libro OWNER TO alumnodb;

--
-- Name: libro_lid_seq; Type: SEQUENCE; Schema: public; Owner: alumnodb
--

CREATE SEQUENCE libro_lid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.libro_lid_seq OWNER TO alumnodb;

--
-- Name: libro_lid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumnodb
--

ALTER SEQUENCE libro_lid_seq OWNED BY libro.lid;


--
-- Name: prestamo; Type: TABLE; Schema: public; Owner: alumnodb; Tablespace: 
--

CREATE TABLE prestamo (
    pid integer NOT NULL,
    lid integer,
    uid integer
);


ALTER TABLE public.prestamo OWNER TO alumnodb;

--
-- Name: prestamo_pid_seq; Type: SEQUENCE; Schema: public; Owner: alumnodb
--

CREATE SEQUENCE prestamo_pid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prestamo_pid_seq OWNER TO alumnodb;

--
-- Name: prestamo_pid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumnodb
--

ALTER SEQUENCE prestamo_pid_seq OWNED BY prestamo.pid;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: alumnodb; Tablespace: 
--

CREATE TABLE usuario (
    uid integer NOT NULL,
    nombreu text
);


ALTER TABLE public.usuario OWNER TO alumnodb;

--
-- Name: usuario_uid_seq; Type: SEQUENCE; Schema: public; Owner: alumnodb
--

CREATE SEQUENCE usuario_uid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_uid_seq OWNER TO alumnodb;

--
-- Name: usuario_uid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumnodb
--

ALTER SEQUENCE usuario_uid_seq OWNED BY usuario.uid;


--
-- Name: lid; Type: DEFAULT; Schema: public; Owner: alumnodb
--

ALTER TABLE ONLY libro ALTER COLUMN lid SET DEFAULT nextval('libro_lid_seq'::regclass);


--
-- Name: pid; Type: DEFAULT; Schema: public; Owner: alumnodb
--

ALTER TABLE ONLY prestamo ALTER COLUMN pid SET DEFAULT nextval('prestamo_pid_seq'::regclass);


--
-- Name: uid; Type: DEFAULT; Schema: public; Owner: alumnodb
--

ALTER TABLE ONLY usuario ALTER COLUMN uid SET DEFAULT nextval('usuario_uid_seq'::regclass);


--
-- Data for Name: libro; Type: TABLE DATA; Schema: public; Owner: alumnodb
--

COPY libro (lid, nombrem) FROM stdin;
1	libro1
2	libro2
3	libro3
4	libro4
\.


--
-- Name: libro_lid_seq; Type: SEQUENCE SET; Schema: public; Owner: alumnodb
--

SELECT pg_catalog.setval('libro_lid_seq', 1, true);


--
-- Data for Name: prestamo; Type: TABLE DATA; Schema: public; Owner: alumnodb
--

COPY prestamo (pid, lid, uid) FROM stdin;
1	1	1
2	1	2
3	2	1
4	2	2
\.


--
-- Name: prestamo_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: alumnodb
--

SELECT pg_catalog.setval('prestamo_pid_seq', 1, true);


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: alumnodb
--

COPY usuario (uid, nombreu) FROM stdin;
1	usuario1
2	usuario2
\.


--
-- Name: usuario_uid_seq; Type: SEQUENCE SET; Schema: public; Owner: alumnodb
--

SELECT pg_catalog.setval('usuario_uid_seq', 1, true);


--
-- Name: libro_pkey; Type: CONSTRAINT; Schema: public; Owner: alumnodb; Tablespace: 
--

ALTER TABLE ONLY libro
    ADD CONSTRAINT libro_pkey PRIMARY KEY (lid);


--
-- Name: prestamo_pkey; Type: CONSTRAINT; Schema: public; Owner: alumnodb; Tablespace: 
--

ALTER TABLE ONLY prestamo
    ADD CONSTRAINT prestamo_pkey PRIMARY KEY (pid);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: alumnodb; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (uid);


--
-- Name: prestamo_lid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alumnodb
--

ALTER TABLE ONLY prestamo
    ADD CONSTRAINT prestamo_lid_fkey FOREIGN KEY (lid) REFERENCES libro(lid);


--
-- Name: prestamo_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alumnodb
--

ALTER TABLE ONLY prestamo
    ADD CONSTRAINT prestamo_uid_fkey FOREIGN KEY (uid) REFERENCES usuario(uid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

