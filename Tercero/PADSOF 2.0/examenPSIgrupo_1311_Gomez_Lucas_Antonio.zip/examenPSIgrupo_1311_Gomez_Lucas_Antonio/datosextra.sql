insert into usuario values(2,'usuario2');
insert into libro values(2,'libro2');
insert into libro values(3,'libro3');
insert into libro values(4,'libro4');
insert into prestamo values(2,1,2);
insert into prestamo values(3,2,1);
insert into prestamo values(4,2,2);
