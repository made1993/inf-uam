/**
*@autor Daniel Garduno Hernandez
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashControl.h"

unsigned int jenkins_one_at_a_time_hash(void *vkey) {
    unsigned hash = 0;
    size_t i;
    unsigned char *key;
    int key_len;


    key = (unsigned char *) vkey;

    key_len = strlen(key);

    for (i = 0; i < key_len; i++) {
        hash += key[i];
        hash += (hash << 10);
        hash ^= (hash >> 6);
    }
    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    return hash;
}

int scmp(const void *a1, const void *a2) {
    char *s1, *s2;
    s1 = (char *) a1;
    s2 = (char *) a2;

    if (strcmp(s1, s2) < 0) return -1;
    if (strcmp(s1, s2) == 0) return 0;

    return 1;
}

void destroy_data(void *a) {
	free((Data *) a);
}

void destr_key(void *s)
{
    free((char *)s);
}

int insertar(hash_table_t* global, hash_table_t* local, char * key, Data* data) {
    hash_node_t *node=NULL;
    if ((global == NULL) || (key == NULL) || (data == NULL)){
        return ERR;
	}
    if (local != NULL) {
        if (((Data *)hash_find_data(local,(void*) key)) != NULL) {
            return ERR;
        }
        hash_insert(local, (void*)key, (void *)data);
        return OK;
    }
    if (((Data *)hash_find_data(global,(void*) key)) != NULL) {
            return ERR;
        }
        hash_insert(global, (void*)key, (void *)data);
        return OK;
}

Data * find(hash_table_t* global, hash_table_t* local, char * key) {
    Data * data;
    hash_node_t *node;

    if ((global == NULL) || (key == NULL)) {
        return NULL;
    }
    if (local != NULL) {
        if ((data = (Data*) hash_find_data(local,(void*) key)) != NULL)
            return data;
    }
    
    data = (Data *) hash_find_data(global,(void *) key);
    if (data != NULL) {
        return data;
    }
    return NULL;
}

