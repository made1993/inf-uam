#ifndef HASHCONTROL_H
#define HASHCONTROL_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "hash.h"

#define ERR 0
#define OK 1

typedef struct {
    int tipo; /*boolean 1, int 2*/
    int clase; /*escalar 1, vector 2*/
    int categoria;
    int tamanio; /*valor para tipo var*/
    int numVarLocales;
    int numParametrosLocales;
    int posVarLocal;
    int posParametro;
} Data;

unsigned int jenkins_one_at_a_time_hash(void *vkey);
int scmp(const void *a1, const void *a2);
void destroy_data(void *a);
void destr_key(void *s);
int insertar(hash_table_t* global, hash_table_t* local, char * key, Data* data);
Data* find(hash_table_t* global, hash_table_t* local, char* key);

#endif
