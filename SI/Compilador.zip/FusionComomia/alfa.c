#include <stdio.h>
#include <stdlib.h>
#include "alfa.h"
#include "hash.h"
#include "hashControl.h"
#include "y.tab.h"

int main(int argc, char **argv){
	int tok=0;
	extern FILE* yyout;
	extern FILE* yyin;

	yyin=fopen(argv[1],"r");
	yyout=fopen(argv[2],"w");

	tok=yyparse();

	fclose(yyin);
	fclose(yyout);
	return 0;
}
