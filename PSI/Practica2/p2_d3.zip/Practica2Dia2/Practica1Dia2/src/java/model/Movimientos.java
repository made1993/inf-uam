/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author e282868
 */
@Entity
@Table(name = "movimientos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Movimientos.findAll", query = "SELECT m FROM Movimientos m"),
    @NamedQuery(name = "Movimientos.findByUsuario", query = "SELECT m FROM Movimientos m WHERE m.movimientosPK.usuario = :usuario"),
    @NamedQuery(name = "Movimientos.findByPartida", query = "SELECT m FROM Movimientos m WHERE m.movimientosPK.partida = :partida"),
    @NamedQuery(name = "Movimientos.findByFila", query = "SELECT m FROM Movimientos m WHERE m.movimientosPK.fila = :fila"),
    @NamedQuery(name = "Movimientos.findByColumna", query = "SELECT m FROM Movimientos m WHERE m.movimientosPK.columna = :columna")})
public class Movimientos implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MovimientosPK movimientosPK;
    @JoinColumn(name = "partida", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Partidas partidas;
    @JoinColumn(name = "usuario", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Jugadores jugadores;

    public Movimientos() {
    }

    public Movimientos(MovimientosPK movimientosPK) {
        this.movimientosPK = movimientosPK;
    }

    public Movimientos(int usuario, int partida, int fila, int columna) {
        this.movimientosPK = new MovimientosPK(usuario, partida, fila, columna);
    }

    public MovimientosPK getMovimientosPK() {
        return movimientosPK;
    }

    public void setMovimientosPK(MovimientosPK movimientosPK) {
        this.movimientosPK = movimientosPK;
    }

    public Partidas getPartidas() {
        return partidas;
    }

    public void setPartidas(Partidas partidas) {
        this.partidas = partidas;
    }

    public Jugadores getJugadores() {
        return jugadores;
    }

    public void setJugadores(Jugadores jugadores) {
        this.jugadores = jugadores;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (movimientosPK != null ? movimientosPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movimientos)) {
            return false;
        }
        Movimientos other = (Movimientos) object;
        if ((this.movimientosPK == null && other.movimientosPK != null) || (this.movimientosPK != null && !this.movimientosPK.equals(other.movimientosPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Movimientos[ movimientosPK=" + movimientosPK + " ]";
    }
    
}
