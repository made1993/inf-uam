/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author e282868
 */
@Embeddable
public class MovimientosPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "usuario")
    private int usuario;
    @Basic(optional = false)
    @Column(name = "partida")
    private int partida;
    @Basic(optional = false)
    @Column(name = "fila")
    private int fila;
    @Basic(optional = false)
    @Column(name = "columna")
    private int columna;

    public MovimientosPK() {
    }

    public MovimientosPK(int usuario, int partida, int fila, int columna) {
        this.usuario = usuario;
        this.partida = partida;
        this.fila = fila;
        this.columna = columna;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public int getPartida() {
        return partida;
    }

    public void setPartida(int partida) {
        this.partida = partida;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) usuario;
        hash += (int) partida;
        hash += (int) fila;
        hash += (int) columna;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MovimientosPK)) {
            return false;
        }
        MovimientosPK other = (MovimientosPK) object;
        if (this.usuario != other.usuario) {
            return false;
        }
        if (this.partida != other.partida) {
            return false;
        }
        if (this.fila != other.fila) {
            return false;
        }
        if (this.columna != other.columna) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.MovimientosPK[ usuario=" + usuario + ", partida=" + partida + ", fila=" + fila + ", columna=" + columna + " ]";
    }
    
}
