/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package webservice;

import com.sun.xml.ws.developer.servlet.HttpSessionScope;
import controller.JugadoresJpaController;
import controller.MovimientosJpaController;
import controller.PartidasJpaController;
import javax.annotation.Resource;
import javax.ejb.Stateful;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import model.Jugadores;
import model.Partidas;

/**
 *
 * @author e282868
 */

@HttpSessionScope
@Stateful
@WebService(serviceName = "WebServiceServer")
public class WebServiceServer {
    
    @PersistenceUnit
    private EntityManagerFactory emf;
    @Resource
    private UserTransaction utx;
    
    private Jugadores user;
    private Partidas partida;

    /**
     * Web service operation
     */
    @WebMethod(operationName = "createUser")
    public ReturnError createUser(@WebParam(name = "userName") String userName, @WebParam(name = "password") String password) {
        JugadoresJpaController jugadoresController = new JugadoresJpaController(utx, emf);
        
        if(jugadoresController.crear_jugador(userName, password)){
            return new ReturnError();
        } else{
            return new ReturnError(-1, "Fallo al crear usuario.");
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "login")
    public ReturnError login(@WebParam(name = "userName") String userName, @WebParam(name = "password") String password) {
        JugadoresJpaController jugadoresController = new JugadoresJpaController(utx, emf);
        
        if(jugadoresController.check_password(userName, password)){
            this.user = new Jugadores();
            this.user.setNombre(userName);
            this.user.setPass(password);
            this.user.setId(jugadoresController.getJugadorID(userName));
            
            return new ReturnError();
        } else{
            return new ReturnError(-1, "Fallo al logear.");
        }
    
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "createGame")
    public ReturnError createGame(@WebParam(name = "humanFirstPlayer") boolean humanFirstPlayer) {
        PartidasJpaController partidasController = new PartidasJpaController(utx,emf);
        
        if(partidasController.crear_partida(this.user.getId(), 0, humanFirstPlayer)){
            this.partida.setJugador1(this.user);
            this.partida.setPrimero(humanFirstPlayer);
            this.partida.setTerminada(0);
            
            return new ReturnError();
        } else{
            return new ReturnError(-1, "Fallo al crear partida.");
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "makeMove")
    public ReturnError makeMove(@WebParam(name = "column") int column) {
        MovimientosJpaController movimientosController = new MovimientosJpaController(utx,emf);
        
        if(movimientosController.crear_movimiento(this.user.getId(), this.partida.getId(), column)){
            return new ReturnError();
        } else{
            return new ReturnError(-1, "Fallo al crear movimiento.");
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "logout")
    @Oneway
    public void logout() {
        this.partida = null;
        this.user = null;
    }
}
