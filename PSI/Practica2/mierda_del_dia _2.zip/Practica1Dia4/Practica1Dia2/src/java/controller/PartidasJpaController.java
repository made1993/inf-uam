/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import controller.exceptions.IllegalOrphanException;
import controller.exceptions.NonexistentEntityException;
import controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import model.Jugadores;
import model.Movimientos;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import model.Partidas;

/**
 *
 * @author e282868
 */
public class PartidasJpaController implements Serializable {

    public PartidasJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Partidas partidas) throws RollbackFailureException, Exception {
        if (partidas.getMovimientosCollection() == null) {
            partidas.setMovimientosCollection(new ArrayList<Movimientos>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Jugadores jugador1 = partidas.getJugador1();
            if (jugador1 != null) {
                jugador1 = em.getReference(jugador1.getClass(), jugador1.getId());
                partidas.setJugador1(jugador1);
            }
            Collection<Movimientos> attachedMovimientosCollection = new ArrayList<Movimientos>();
            for (Movimientos movimientosCollectionMovimientosToAttach : partidas.getMovimientosCollection()) {
                movimientosCollectionMovimientosToAttach = em.getReference(movimientosCollectionMovimientosToAttach.getClass(), movimientosCollectionMovimientosToAttach.getMovimientosPK());
                attachedMovimientosCollection.add(movimientosCollectionMovimientosToAttach);
            }
            partidas.setMovimientosCollection(attachedMovimientosCollection);
            em.persist(partidas);
            if (jugador1 != null) {
                jugador1.getPartidasCollection().add(partidas);
                jugador1 = em.merge(jugador1);
            }
            for (Movimientos movimientosCollectionMovimientos : partidas.getMovimientosCollection()) {
                Partidas oldPartidasOfMovimientosCollectionMovimientos = movimientosCollectionMovimientos.getPartidas();
                movimientosCollectionMovimientos.setPartidas(partidas);
                movimientosCollectionMovimientos = em.merge(movimientosCollectionMovimientos);
                if (oldPartidasOfMovimientosCollectionMovimientos != null) {
                    oldPartidasOfMovimientosCollectionMovimientos.getMovimientosCollection().remove(movimientosCollectionMovimientos);
                    oldPartidasOfMovimientosCollectionMovimientos = em.merge(oldPartidasOfMovimientosCollectionMovimientos);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Partidas partidas) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Partidas persistentPartidas = em.find(Partidas.class, partidas.getId());
            Jugadores jugador1Old = persistentPartidas.getJugador1();
            Jugadores jugador1New = partidas.getJugador1();
            Collection<Movimientos> movimientosCollectionOld = persistentPartidas.getMovimientosCollection();
            Collection<Movimientos> movimientosCollectionNew = partidas.getMovimientosCollection();
            List<String> illegalOrphanMessages = null;
            for (Movimientos movimientosCollectionOldMovimientos : movimientosCollectionOld) {
                if (!movimientosCollectionNew.contains(movimientosCollectionOldMovimientos)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Movimientos " + movimientosCollectionOldMovimientos + " since its partidas field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (jugador1New != null) {
                jugador1New = em.getReference(jugador1New.getClass(), jugador1New.getId());
                partidas.setJugador1(jugador1New);
            }
            Collection<Movimientos> attachedMovimientosCollectionNew = new ArrayList<Movimientos>();
            for (Movimientos movimientosCollectionNewMovimientosToAttach : movimientosCollectionNew) {
                movimientosCollectionNewMovimientosToAttach = em.getReference(movimientosCollectionNewMovimientosToAttach.getClass(), movimientosCollectionNewMovimientosToAttach.getMovimientosPK());
                attachedMovimientosCollectionNew.add(movimientosCollectionNewMovimientosToAttach);
            }
            movimientosCollectionNew = attachedMovimientosCollectionNew;
            partidas.setMovimientosCollection(movimientosCollectionNew);
            partidas = em.merge(partidas);
            if (jugador1Old != null && !jugador1Old.equals(jugador1New)) {
                jugador1Old.getPartidasCollection().remove(partidas);
                jugador1Old = em.merge(jugador1Old);
            }
            if (jugador1New != null && !jugador1New.equals(jugador1Old)) {
                jugador1New.getPartidasCollection().add(partidas);
                jugador1New = em.merge(jugador1New);
            }
            for (Movimientos movimientosCollectionNewMovimientos : movimientosCollectionNew) {
                if (!movimientosCollectionOld.contains(movimientosCollectionNewMovimientos)) {
                    Partidas oldPartidasOfMovimientosCollectionNewMovimientos = movimientosCollectionNewMovimientos.getPartidas();
                    movimientosCollectionNewMovimientos.setPartidas(partidas);
                    movimientosCollectionNewMovimientos = em.merge(movimientosCollectionNewMovimientos);
                    if (oldPartidasOfMovimientosCollectionNewMovimientos != null && !oldPartidasOfMovimientosCollectionNewMovimientos.equals(partidas)) {
                        oldPartidasOfMovimientosCollectionNewMovimientos.getMovimientosCollection().remove(movimientosCollectionNewMovimientos);
                        oldPartidasOfMovimientosCollectionNewMovimientos = em.merge(oldPartidasOfMovimientosCollectionNewMovimientos);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = partidas.getId();
                if (findPartidas(id) == null) {
                    throw new NonexistentEntityException("The partidas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Partidas partidas;
            try {
                partidas = em.getReference(Partidas.class, id);
                partidas.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The partidas with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Movimientos> movimientosCollectionOrphanCheck = partidas.getMovimientosCollection();
            for (Movimientos movimientosCollectionOrphanCheckMovimientos : movimientosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Partidas (" + partidas + ") cannot be destroyed since the Movimientos " + movimientosCollectionOrphanCheckMovimientos + " in its movimientosCollection field has a non-nullable partidas field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Jugadores jugador1 = partidas.getJugador1();
            if (jugador1 != null) {
                jugador1.getPartidasCollection().remove(partidas);
                jugador1 = em.merge(jugador1);
            }
            em.remove(partidas);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Partidas> findPartidasEntities() {
        return findPartidasEntities(true, -1, -1);
    }

    public List<Partidas> findPartidasEntities(int maxResults, int firstResult) {
        return findPartidasEntities(false, maxResults, firstResult);
    }

    private List<Partidas> findPartidasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Partidas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Partidas findPartidas(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Partidas.class, id);
        } finally {
            em.close();
        }
    }

    public int getPartidasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Partidas> rt = cq.from(Partidas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    public List<Partidas> getPartidasTerminadas() {
        EntityManager em = getEntityManager();
        try {
            String sqlCommand = "SELECT p FROM Partidas p WHERE p.terminada = 1";
            Query q = em.createQuery(sqlCommand);
            //q.setParameter("t", 1);

            List<Partidas> l = new ArrayList<Partidas>();
            for(Object o:q.getResultList()){
                l.add((Partidas)o);
            }
            
            return (l);
        } finally {
            em.close();
        }
    }

    public boolean crear_partida(Integer id, int i, boolean humanFirstPlayer) {
        EntityManager em = getEntityManager();
        try {
           String sqlCommand = "INSERT INTO Partidas VALUES("+id+","+i+","+humanFirstPlayer+");" ;
           Query q = em.createNativeQuery(sqlCommand);
           
           
           return true;
        } catch(Exception e){
            return false;
        } finally {
            em.close();
        }
        
        
    }
}
